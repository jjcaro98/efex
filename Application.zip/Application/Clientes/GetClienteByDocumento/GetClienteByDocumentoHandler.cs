using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;
using Microsoft.Extensions.Logging;
using Renting.BaseLine.Application.Clientes.GetClientes;
using Renting.BaseLine.Application.Exceptions;

namespace Renting.BaseLine.Application.Clientes.GetClienteByDocumento
{
    public class GetClienteByDocumentoHandler : IRequestHandler<GetClienteByDocumentoQuery, ClienteDto>
    {
        private readonly IRepository<Cliente> _clienteRepository;
        private readonly ILogger<GetClienteByDocumentoHandler> _logger;

        public GetClienteByDocumentoHandler(IRepository<Cliente> clienteRepository, ILogger<GetClienteByDocumentoHandler> logger)
        {
            _clienteRepository = clienteRepository;
            _logger = logger;
        }        public async Task<ClienteDto> Handle(GetClienteByDocumentoQuery request, CancellationToken cancellationToken)
        {
            try
            {
                // Búsqueda insensible a mayúsculas/minúsculas
                var documentoLowerCase = request.Documento.ToLower();
                var clientes = await _clienteRepository.GetAsync(c => c.Documento.ToLower().Contains(documentoLowerCase));
                var cliente = clientes.FirstOrDefault();
                
                if (cliente == null)
                {
                    _logger.LogWarning("Cliente no encontrado con documento que contenga: {Documento}", request.Documento);
                    throw new NotFoundException($"No se encontró ningún cliente con documento que contenga {request.Documento}");
                }

                return new ClienteDto
                {
                    IdCliente = cliente.IdCliente,
                    Nombre = cliente.Nombre,
                    Apellido = cliente.Apellido,
                    Documento = cliente.Documento,
                    Email = cliente.Email,
                    Telefono = cliente.Telefono
                };
            }
            catch (Exception ex) when (!(ex is NotFoundException))
            {
                _logger.LogError(ex, "Error al buscar cliente por documento: {Documento}", request.Documento);
                throw new ApplicationException($"Error al buscar cliente con documento {request.Documento}", ex);
            }
        }
    }
}
