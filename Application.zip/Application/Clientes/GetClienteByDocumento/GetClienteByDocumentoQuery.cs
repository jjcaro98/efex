using MediatR;
using Renting.BaseLine.Application.Clientes.GetClientes;

namespace Renting.BaseLine.Application.Clientes.GetClienteByDocumento
{
    public class GetClienteByDocumentoQuery : IRequest<ClienteDto>
    {
        public string Documento { get; set; }

        public GetClienteByDocumentoQuery(string documento)
        {
            Documento = documento;
        }
    }
}
