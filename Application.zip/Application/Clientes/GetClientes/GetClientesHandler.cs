using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;
using Microsoft.Extensions.Logging;

namespace Renting.BaseLine.Application.Clientes.GetClientes
{
    public class GetClientesHandler : IRequestHandler<GetClientesQuery, IEnumerable<ClienteDto>>
    {
        private readonly IRepository<Cliente> _clienteRepository;
        private readonly ILogger<GetClientesHandler> _logger;

        public GetClientesHandler(IRepository<Cliente> clienteRepository, ILogger<GetClientesHandler> logger)
        {
            _clienteRepository = clienteRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<ClienteDto>> Handle(GetClientesQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var clientes = await _clienteRepository.GetAsync();
                return clientes.Select(c => new ClienteDto
                {
                    IdCliente = c.IdCliente,
                    Nombre = c.Nombre,
                    Apellido = c.Apellido,
                    Documento = c.Documento,
                    Email = c.Email,
                    Telefono = c.Telefono
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener los clientes");
                throw new ApplicationException("Error al obtener los clientes", ex);
            }
        }
    }
}
