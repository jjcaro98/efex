using MediatR;
using System.Collections.Generic;

namespace Renting.BaseLine.Application.Clientes.GetClientes
{
    public class GetClientesQuery : IRequest<IEnumerable<ClienteDto>>
    {
    }
}
