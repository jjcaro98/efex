using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;
using Microsoft.Extensions.Logging;
using Renting.BaseLine.Application.Clientes.GetClientes;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System;

namespace Renting.BaseLine.Application.Clientes.GetClientesByDocumento
{
    public class GetClientesByDocumentoHandler : IRequestHandler<GetClientesByDocumentoQuery, IEnumerable<ClienteDto>>
    {
        private readonly IRepository<Cliente> _clienteRepository;
        private readonly ILogger<GetClientesByDocumentoHandler> _logger;

        public GetClientesByDocumentoHandler(IRepository<Cliente> clienteRepository, ILogger<GetClientesByDocumentoHandler> logger)
        {
            _clienteRepository = clienteRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<ClienteDto>> Handle(GetClientesByDocumentoQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var documentoLowerCase = request.Documento.ToLower();
                var clientes = await _clienteRepository.GetAsync(c => c.Documento.ToLower().Contains(documentoLowerCase));
                
                if (!clientes.Any())
                {
                    _logger.LogWarning("No se encontraron clientes con documento que contenga: {Documento}", request.Documento);
                    return Enumerable.Empty<ClienteDto>();
                }

                return clientes.Select(c => new ClienteDto
                {
                    IdCliente = c.IdCliente,
                    Nombre = c.Nombre,
                    Apellido = c.Apellido,
                    Documento = c.Documento,
                    Email = c.Email,
                    Telefono = c.Telefono
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al buscar clientes por documento parcial: {Documento}", request.Documento);
                throw new ApplicationException($"Error al buscar clientes con documento parcial {request.Documento}", ex);
            }
        }
    }
}
