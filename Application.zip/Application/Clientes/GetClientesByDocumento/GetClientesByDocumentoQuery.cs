using MediatR;
using Renting.BaseLine.Application.Clientes.GetClientes;
using System.Collections.Generic;

namespace Renting.BaseLine.Application.Clientes.GetClientesByDocumento
{
    public class GetClientesByDocumentoQuery : IRequest<IEnumerable<ClienteDto>>
    {
        public string Documento { get; set; }

        public GetClientesByDocumentoQuery(string documento)
        {
            Documento = documento;
        }
    }
}
