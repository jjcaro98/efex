﻿using System.ComponentModel.DataAnnotations;
using MediatR;
using Renting.BaseLine.Application.People.Shared;

namespace Renting.BaseLine.Application.People.FindPerson
{
    public record FindPersonQuery([Required] int Id) : IRequest<PersonDto>;
}
