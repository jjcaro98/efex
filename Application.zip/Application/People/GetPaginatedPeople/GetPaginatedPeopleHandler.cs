﻿using AutoMapper;
using MediatR;
using Renting.BaseLine.Application.People.Shared;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.People.GetPaginatedPeople
{
    public class GetPaginatedPeopleHandler : IRequestHandler<GetPaginatedPeopleQuery, IPaginatedResult<PersonDto>>
    {
        private readonly IRepository<Person> _repository;
        private readonly IMapper _mapper;

        public GetPaginatedPeopleHandler(IRepository<Person> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<IPaginatedResult<PersonDto>> Handle(GetPaginatedPeopleQuery request, CancellationToken cancellationToken)
        {
            var paginatedPeople = await _repository.GetPaginatedAsync(request.PageIndex, request.PageSize);

            return paginatedPeople.CreateFrom(_mapper.Map<IEnumerable<PersonDto>>(paginatedPeople.Items));
        }
    }
}
