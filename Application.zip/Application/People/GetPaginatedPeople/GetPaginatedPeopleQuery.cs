﻿using MediatR;
using Renting.BaseLine.Application.People.Shared;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.People.GetPaginatedPeople
{
    public record GetPaginatedPeopleQuery(int PageIndex, int PageSize) : IRequest<IPaginatedResult<PersonDto>>;
}
