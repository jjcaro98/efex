﻿using MediatR;
using Renting.BaseLine.Application.People.Shared;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.People.GetPaginatedPeopleByStoredProcedure
{
    public record GetPaginatedPeopleByStoredProcedureQuery(
        int PageIndex,
        int PageSize) : IRequest<IPaginatedResult<PersonDto>>;
}
