﻿using AutoMapper;
using MediatR;
using Renting.BaseLine.Application.People.Shared;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.People.GetPeople
{
    public class GetPeopleHandler : IRequestHandler<GetPeopleQuery, IEnumerable<PersonDto>>
    {
        private readonly IPeopleRepository _repository;
        private readonly IMapper _mapper;

        public GetPeopleHandler(IPeopleRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<PersonDto>> Handle(GetPeopleQuery _, CancellationToken cancellationToken)
        {
            var people = await _repository.GetAsync();

            return _mapper.Map<IEnumerable<PersonDto>>(people);
        }
    }
}
