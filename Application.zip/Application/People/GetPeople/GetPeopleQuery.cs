﻿using System.ComponentModel.DataAnnotations;
using MediatR;
using Renting.BaseLine.Application.People.Shared;

namespace Renting.BaseLine.Application.People.GetPeople
{
    public record GetPeopleQuery() : IRequest<IEnumerable<PersonDto>>;
}
