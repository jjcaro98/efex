﻿using AutoMapper;
using Renting.BaseLine.Application.People.CreatePeople;
using Renting.BaseLine.Application.People.CreatePerson;
using Renting.BaseLine.Application.People.GetPaginatedPeopleByStoredProcedure;
using Renting.BaseLine.Application.People.Shared;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories.Criteria;

namespace Renting.BaseLine.Application.People
{
    public class PersonProfile : Profile
    {
        public PersonProfile()
        {
            CreateMap<CreatePersonCommand, Person>();
            CreateMap<CreatePeopleCommand.Person, CreatePersonCommand>();
            CreateMap<Person, PersonDto>();
            CreateMap<GetPaginatedPeopleByStoredProcedureQuery, PeopleSPCriteria>();
            CreateMap<PeopleSP, PersonDto>();
        }
    }
}
