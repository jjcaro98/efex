﻿using MediatR;
using Renting.BaseLine.Application.People.CreatePeople;
using Renting.BaseLine.Application.Services;

namespace Renting.BaseLine.Application.People.SendCreatePeople
{
    public class SendCreatePeopleHandler : IRequestHandler<SendCreatePeopleCommand>
    {
        private readonly IMessageService _messageService;

        public SendCreatePeopleHandler(IMessageService messageService)
        {
            _messageService = messageService;
        }

        public async Task Handle(SendCreatePeopleCommand request, CancellationToken cancellationToken)
        {
            await _messageService.SendAsync<CreatePeopleCommand>(request);
        }
    }
}
