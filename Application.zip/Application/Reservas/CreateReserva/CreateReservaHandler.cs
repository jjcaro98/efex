﻿using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;
using Microsoft.Extensions.Logging;

namespace Renting.BaseLine.Application.Reservas.CreateReserva
{
    public class CreateReservaHandler : IRequestHandler<CreateReservaCommand, ReservaDto>
    {
        private readonly IRepository<Reserva> _reservaRepository;
        private readonly IRepository<Vehiculo> _vehiculoRepository;
        private readonly ILogger<CreateReservaHandler> _logger;

        public CreateReservaHandler(IRepository<Reserva> reservaRepository, IRepository<Vehiculo> vehiculoRepository, ILogger<CreateReservaHandler> logger)
        {
            _reservaRepository = reservaRepository;
            _vehiculoRepository = vehiculoRepository;
            _logger = logger;
        }

        public async Task<ReservaDto> Handle(CreateReservaCommand request, CancellationToken cancellationToken)
        {
            try
            {
                // Validar que el vehículo no tenga otra reserva activa en el rango solicitado (comparando solo fechas)
                var reservasActivas = await _reservaRepository.GetAsync(r =>
                    r.IdVehiculo == request.IdVehiculo &&
                    r.IdEstadoReserva != 3 && // 3 = Cancelada
                    r.FechaInicio.Date <= request.FechaFin.Date &&
                    r.FechaFin.Date >= request.FechaInicio.Date
                );
                if (reservasActivas.Any())
                    throw new ApplicationException("El vehículo ya tiene una reserva activa en esas fechas.");

                var reserva = new Reserva
                {
                    IdVehiculo = request.IdVehiculo,
                    IdCliente = request.IdCliente,
                    FechaInicio = request.FechaInicio,
                    FechaFin = request.FechaFin,
                    IdEstadoReserva = request.IdEstadoReserva
                };
                var nuevaReserva = await _reservaRepository.AddAsync(reserva);

                // Si la reserva inicia hoy, cambiar el estado del vehículo a "alquilado" (IdEstadoVehiculo = 2)
                if (request.FechaInicio.Date == DateTime.Today)
                {
                    var vehiculo = await _vehiculoRepository.FindAsync(request.IdVehiculo);
                    if (vehiculo != null)
                    {
                        vehiculo.IdEstadoVehiculo = 2; // 2 = Alquilado
                        await _vehiculoRepository.UpdateAsync(vehiculo);
                    }
                }

                return new ReservaDto
                {
                    IdReserva = nuevaReserva.IdReserva,
                    IdVehiculo = nuevaReserva.IdVehiculo,
                    IdCliente = nuevaReserva.IdCliente,
                    FechaInicio = nuevaReserva.FechaInicio,
                    FechaFin = nuevaReserva.FechaFin,
                    IdEstadoReserva = nuevaReserva.IdEstadoReserva
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al crear la reserva");
                throw new ApplicationException("Error al crear la reserva", ex);
            }
        }
    }
}
