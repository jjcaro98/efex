using System;

namespace Renting.BaseLine.Application.Reservas.CreateReserva
{
    public class ReservaDto
    {
        public int IdReserva { get; set; }
        public int IdVehiculo { get; set; }
        public int IdCliente { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public int IdEstadoReserva { get; set; }
    }
}
