﻿namespace Renting.BaseLine.Application.Services.Notifications
{
    public record EmailUserName(string Email, string UserName);
}
