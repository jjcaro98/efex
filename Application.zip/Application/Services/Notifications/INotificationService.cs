﻿namespace Renting.BaseLine.Application.Services.Notifications
{
    public interface INotificationService
    {
        Task SendAsync(EmailUserName sender, IEnumerable<EmailUserName> recipients, string title, string content = "");
    }
}
