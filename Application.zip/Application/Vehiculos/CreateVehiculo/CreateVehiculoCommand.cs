using System.ComponentModel.DataAnnotations;
using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Application.Vehiculos.CreateVehiculo;

namespace Renting.BaseLine.Application.Vehiculos.CreateVehiculo
{
    public class CreateVehiculoCommand : IRequest<VehiculoDto>
    {
        [Required]
        [MaxLength(20)]
        public string Placa { get; set; } = default!;

        [Required]
        [MaxLength(50)]
        public string Marca { get; set; } = default!;

        [Required]
        [MaxLength(50)]
        public string Modelo { get; set; } = default!;

        [Required]
        public int Anio { get; set; }

        [Required]
        public int IdTipoVehiculo { get; set; }

        [Required]
        public int IdEstadoVehiculo { get; set; }
    }
}
