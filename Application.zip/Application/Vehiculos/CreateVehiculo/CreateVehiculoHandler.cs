using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.Vehiculos.CreateVehiculo
{
    public class CreateVehiculoHandler : IRequestHandler<CreateVehiculoCommand, VehiculoDto>
    {
        private readonly IRepository<Vehiculo> _vehiculoRepository;
        public CreateVehiculoHandler(IRepository<Vehiculo> vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<VehiculoDto> Handle(CreateVehiculoCommand request, CancellationToken cancellationToken)
        {
            var vehiculo = new Vehiculo
            {
                Placa = request.Placa,
                Marca = request.Marca,
                Modelo = request.Modelo,
                Anio = request.Anio,
                IdTipoVehiculo = request.IdTipoVehiculo,
                IdEstadoVehiculo = request.IdEstadoVehiculo
            };
            await _vehiculoRepository.AddAsync(vehiculo);
            return new VehiculoDto
            {
                IdVehiculo = vehiculo.IdVehiculo,
                Placa = vehiculo.Placa,
                Marca = vehiculo.Marca,
                Modelo = vehiculo.Modelo,
                Anio = vehiculo.Anio,
                IdTipoVehiculo = vehiculo.IdTipoVehiculo,
                IdEstadoVehiculo = vehiculo.IdEstadoVehiculo
            };
        }
    }
}
