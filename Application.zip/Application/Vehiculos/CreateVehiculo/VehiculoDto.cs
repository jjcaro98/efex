using System;

namespace Renting.BaseLine.Application.Vehiculos.CreateVehiculo
{
    public class VehiculoDto
    {
        public int IdVehiculo { get; set; }
        public string Placa { get; set; } = string.Empty;
        public string Marca { get; set; } = string.Empty;
        public string Modelo { get; set; } = string.Empty;
        public int Anio { get; set; }
        public int IdTipoVehiculo { get; set; }
        public int IdEstadoVehiculo { get; set; }
    }
}
