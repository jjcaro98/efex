﻿using MediatR;
using Microsoft.Extensions.Logging;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.Vehiculos.GetVehiculos
{
    public class GetVehiculosByEstadoYFechaHandler : IRequestHandler<GetVehiculosByEstadoYFechaQuery, IEnumerable<object>>
    {
        private readonly IRepository<Vehiculo> _vehiculoRepository;
        private readonly IRepository<EstadoVehiculo> _estadoVehiculoRepository;
        private readonly IRepository<Reserva> _reservaRepository;
        private readonly IRepository<TipoVehiculo> _tipoVehiculoRepository;
        private readonly ILogger<GetVehiculosByEstadoYFechaHandler> _logger;

        public GetVehiculosByEstadoYFechaHandler(
            IRepository<Vehiculo> vehiculoRepository,
            IRepository<EstadoVehiculo> estadoVehiculoRepository,
            IRepository<Reserva> reservaRepository,
            IRepository<TipoVehiculo> tipoVehiculoRepository,
            ILogger<GetVehiculosByEstadoYFechaHandler> logger)
        {
            _vehiculoRepository = vehiculoRepository;
            _estadoVehiculoRepository = estadoVehiculoRepository;
            _reservaRepository = reservaRepository;
            _tipoVehiculoRepository = tipoVehiculoRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<object>> Handle(GetVehiculosByEstadoYFechaQuery request, CancellationToken cancellationToken)
        {
            try
            {
                IEnumerable<Vehiculo> vehiculos;
                var tipoVehiculos = await _tipoVehiculoRepository.GetAsync();
                var estadosVehiculo = await _estadoVehiculoRepository.GetAsync();

                if (string.IsNullOrEmpty(request.EstadoDescripcion))
                {
                    vehiculos = await _vehiculoRepository.GetAsync();
                }
                else
                {
                    // Filtrar por la descripción del tipo de vehículo (ignorando mayúsculas/minúsculas y espacios)
                    var tipo = tipoVehiculos.FirstOrDefault(t => t.Descripcion.Trim().ToLower() == request.EstadoDescripcion.Trim().ToLower());
                    if (tipo == null)
                        return Enumerable.Empty<object>();
                    vehiculos = await _vehiculoRepository.GetAsync(v => v.IdTipoVehiculo == tipo.IdTipoVehiculo);
                    // Solo considerar vehículos con IdEstadoVehiculo = 1 (DISPONIBLE)
                    vehiculos = vehiculos.Where(v => v.IdEstadoVehiculo == 1).ToList();
                }

         

                // Traer todas las reservas de los vehículos filtrados
                var reservas = await _reservaRepository.GetAsync(r => vehiculos.Select(v => v.IdVehiculo).Contains(r.IdVehiculo));

                // Si se indica fecha o tipo de vehículo, filtrar solo los disponibles en la fecha indicada (o todos si no hay fecha ni tipo)
                IEnumerable<Vehiculo> vehiculosDisponibles = vehiculos;
                if (request.Fecha.HasValue || !string.IsNullOrEmpty(request.EstadoDescripcion))
                {
                    DateTime? fecha = request.Fecha?.Date;
                    // Si no hay fecha, usar hoy
                    if (!fecha.HasValue)
                        fecha = DateTime.Today;
                    var vehiculosNoDisponibles = reservas
                        .Where(r => r.FechaInicio.Date <= fecha && r.FechaFin.Date >= fecha)
                        .Select(r => r.IdVehiculo)
                        .Distinct()
                        .ToHashSet();
                    vehiculosDisponibles = vehiculos.Where(v => !vehiculosNoDisponibles.Contains(v.IdVehiculo));
                }

                // Unir cada vehículo disponible con sus reservas (puede haber varias por vehículo)
                var resultado = from v in vehiculosDisponibles
                                join r in reservas on v.IdVehiculo equals r.IdVehiculo into res
                                from r in res.DefaultIfEmpty()
                                join t in tipoVehiculos on v.IdTipoVehiculo equals t.IdTipoVehiculo into tipos
                                from t in tipos.DefaultIfEmpty()
                                join e in estadosVehiculo on v.IdEstadoVehiculo equals e.IdEstadoVehiculo into estados
                                from e in estados.DefaultIfEmpty()
                                select new {
                                    v.IdVehiculo,
                                    v.Placa,
                                    v.Marca,
                                    v.Modelo,
                                    v.Anio,
                                    v.IdTipoVehiculo,
                                    TipoVehiculoDescripcion = t != null ? t.Descripcion : null,
                                    v.IdEstadoVehiculo,
                                    EstadoVehiculoDescripcion = e != null ? e.Descripcion : null,
                                    FechaInicio = r != null ? (DateTime?)r.FechaInicio : null,
                                    FechaFin = r != null ? (DateTime?)r.FechaFin : null
                                };
                return resultado;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener los vehículos filtrados");
                throw new ApplicationException("Error al obtener los vehículos filtrados", ex);
            }
        }
    }
}
