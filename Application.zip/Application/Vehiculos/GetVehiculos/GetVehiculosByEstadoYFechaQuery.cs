using MediatR;
using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Application.Vehiculos.GetVehiculos
{
    public class GetVehiculosByEstadoYFechaQuery : IRequest<IEnumerable<object>>
    {
        public string EstadoDescripcion { get; set; } = default!;
        public DateTime? Fecha { get; set; }
    }
}
