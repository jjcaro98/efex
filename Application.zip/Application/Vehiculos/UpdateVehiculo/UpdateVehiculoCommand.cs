using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Renting.BaseLine.Application.Vehiculos.UpdateVehiculo
{
    public class UpdateVehiculoCommand : IRequest<bool>
    {
        [Required]
        public int IdVehiculo { get; set; }
        [Required]
        [MaxLength(20)]
        public string Placa { get; set; } = default!;
        [Required]
        [MaxLength(50)]
        public string Marca { get; set; } = default!;
        [Required]
        [MaxLength(50)]
        public string Modelo { get; set; } = default!;
        [Required]
        public int Anio { get; set; }
        [Required]
        public int IdTipoVehiculo { get; set; }
        [Required]
        public int IdEstadoVehiculo { get; set; }
    }
}
