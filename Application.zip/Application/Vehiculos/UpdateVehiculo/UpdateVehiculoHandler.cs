using MediatR;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.Application.Vehiculos.UpdateVehiculo
{
    public class UpdateVehiculoHandler : IRequestHandler<UpdateVehiculoCommand, bool>
    {
        private readonly IRepository<Vehiculo> _vehiculoRepository;
        public UpdateVehiculoHandler(IRepository<Vehiculo> vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<bool> Handle(UpdateVehiculoCommand request, CancellationToken cancellationToken)
        {
            var vehiculos = await _vehiculoRepository.GetAsync(v => v.IdVehiculo == request.IdVehiculo);
            var vehiculo = vehiculos.FirstOrDefault();
            if (vehiculo == null)
                return false;
            vehiculo.Placa = request.Placa;
            vehiculo.Marca = request.Marca;
            vehiculo.Modelo = request.Modelo;
            vehiculo.Anio = request.Anio;
            vehiculo.IdTipoVehiculo = request.IdTipoVehiculo;
            vehiculo.IdEstadoVehiculo = request.IdEstadoVehiculo;
            await _vehiculoRepository.UpdateAsync(vehiculo);
            return true;
        }
    }
}
