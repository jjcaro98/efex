﻿namespace Renting.BaseLine.Domain.Entities.Base
{
    public class DomainEntity
    {

    }
}
