using System.ComponentModel.DataAnnotations;
using Renting.BaseLine.Domain.Entities.Base;

namespace Renting.BaseLine.Domain.Entities
{
    public class Cliente : DomainEntity
    {
        [Key]
        public int IdCliente { get; set; }

        [Required]
        [MaxLength(100)]
        public string Nombre { get; set; } = default!;

        [Required]
        [MaxLength(100)]
        public string Apellido { get; set; } = default!;

        [Required]
        [MaxLength(20)]
        public string Documento { get; set; } = default!;

        [MaxLength(100)]
        public string? Email { get; set; }

        [MaxLength(20)]
        public string? Telefono { get; set; }
    }
}
