using System.ComponentModel.DataAnnotations;

namespace Renting.BaseLine.Domain.Entities
{
    public class EstadoReserva
    {
        [Key]
        public int IdEstadoReserva { get; set; }

        [Required]
        [MaxLength(50)]
        public string Descripcion { get; set; } = default!;
    }
}
