using System.ComponentModel.DataAnnotations;
using Renting.BaseLine.Domain.Entities.Base;

namespace Renting.BaseLine.Domain.Entities
{
    public class EstadoVehiculo : DomainEntity
    {
        [Key]
        public int IdEstadoVehiculo { get; set; }

        [Required]
        [MaxLength(50)]
        public string Descripcion { get; set; } = default!;
    }
}
