using System;
using System.ComponentModel.DataAnnotations;
using Renting.BaseLine.Domain.Entities.Base;

namespace Renting.BaseLine.Domain.Entities
{
    public class Reserva : DomainEntity
    {
        [Key]
        public int IdReserva { get; set; }

        [Required]
        public int IdVehiculo { get; set; }

        [Required]
        public int IdCliente { get; set; }

        [Required]
        public DateTime FechaInicio { get; set; }

        [Required]
        public DateTime FechaFin { get; set; }

        [Required]
        public int IdEstadoReserva { get; set; }

        // Eliminar propiedades de navegación para evitar columnas extra
    }
}
