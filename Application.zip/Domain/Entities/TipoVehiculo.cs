using System.ComponentModel.DataAnnotations;
using Renting.BaseLine.Domain.Entities.Base;

namespace Renting.BaseLine.Domain.Entities
{
    public class TipoVehiculo : DomainEntity
    {
        [Key]
        public int IdTipoVehiculo { get; set; }

        [Required]
        [MaxLength(100)]
        public string Descripcion { get; set; } = default!;
    }
}
