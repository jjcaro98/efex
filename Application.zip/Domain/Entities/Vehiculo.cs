using System.ComponentModel.DataAnnotations;
using Renting.BaseLine.Domain.Entities.Base;

namespace Renting.BaseLine.Domain.Entities
{
    public class Vehiculo : DomainEntity
    {
        [Key]
        public int IdVehiculo { get; set; }

        [Required]
        [MaxLength(20)]
        public string Placa { get; set; } = default!;

        [Required]
        [MaxLength(50)]
        public string Marca { get; set; } = default!;

        [Required]
        [MaxLength(50)]
        public string Modelo { get; set; } = default!;

        [Required]
        public int Anio { get; set; }

        [Required]
        public int IdTipoVehiculo { get; set; }

        [Required]
        public int IdEstadoVehiculo { get; set; }
    }
}
