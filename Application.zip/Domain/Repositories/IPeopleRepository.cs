﻿using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Domain.Repositories
{
    public interface IPeopleRepository : IRepository<Person>
    {
        Task<IEnumerable<Person>> GetPeopleAsync(object instance);
        Task<IEnumerable<Person>> GetPeopleAsync(string firstName, string lastName);
    }
}
