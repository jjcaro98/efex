﻿using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories.Criteria;

namespace Renting.BaseLine.Domain.Repositories
{
    public interface IPeopleSPRepository : IRepository<PeopleSP>
    {
        Task<IPaginatedResult<PeopleSP>> GetPeoplePaginatedAsync(PeopleSPCriteria criteria);
    }
}
