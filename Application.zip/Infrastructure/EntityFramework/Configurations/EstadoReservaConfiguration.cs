using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Infrastructure.EntityFramework.Configurations
{
    public class EstadoReservaConfiguration : IEntityTypeConfiguration<EstadoReserva>
    {
        public void Configure(EntityTypeBuilder<EstadoReserva> builder)
        {
            builder.ToTable("EstadoReserva");
        }
    }
}
