using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Infrastructure.EntityFramework.Configurations
{
    public class EstadoVehiculoConfiguration : IEntityTypeConfiguration<EstadoVehiculo>
    {
        public void Configure(EntityTypeBuilder<EstadoVehiculo> builder)
        {
            builder.ToTable("EstadoVehiculo"); // Nombre exacto de la tabla en la base de datos
        }
    }
}
