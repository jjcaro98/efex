﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Infrastructure.EntityFramework.Configurations
{
    public class PeopleSPEntityConfiguration : IEntityTypeConfiguration<PeopleSP>
    {
        public void Configure(EntityTypeBuilder<PeopleSP> builder)
        {
            builder.HasNoKey();

            builder.Property(x => x.FirstName)
                .IsRequired();

            builder.Property(x => x.LastName)
                .IsRequired();
        }
    }
}
