using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Infrastructure.EntityFramework.Configurations
{
    public class ReservaConfiguration : IEntityTypeConfiguration<Reserva>
    {
        public void Configure(EntityTypeBuilder<Reserva> builder)
        {
            builder.ToTable("Reserva");

            // Configuración explícita de las claves foráneas para evitar columnas shadow
            builder.HasOne<Cliente>()
                .WithMany()
                .HasForeignKey(r => r.IdCliente)
                .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne<Vehiculo>()
                .WithMany()
                .HasForeignKey(r => r.IdVehiculo)
                .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne<EstadoReserva>()
                .WithMany()
                .HasForeignKey(r => r.IdEstadoReserva)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
