using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Renting.BaseLine.Domain.Entities;

namespace Renting.BaseLine.Infrastructure.EntityFramework.Configurations
{
    public class TipoVehiculoConfiguration : IEntityTypeConfiguration<TipoVehiculo>
    {
        public void Configure(EntityTypeBuilder<TipoVehiculo> builder)
        {
            builder.ToTable("TipoVehiculo");
        }
    }
}
