﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Renting.BaseLine.Infrastructure.EntityFramework
{
    public class PersistenceContext : DbContext
    {
        private readonly IConfiguration _configuration;

        public PersistenceContext(DbContextOptions<PersistenceContext> options, IConfiguration configuration) : base(options)
        {
            _configuration = configuration;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            if (modelBuilder == null)
            {
                return;
            }
            modelBuilder.HasDefaultSchema(_configuration.GetConnectionString("BaseSchema"));
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(PersistenceContext).Assembly);

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Renting.BaseLine.Domain.Entities.EstadoVehiculo> EstadoVehiculos { get; set; }
        public DbSet<Renting.BaseLine.Domain.Entities.Vehiculo> Vehiculos { get; set; }
        public DbSet<Renting.BaseLine.Domain.Entities.Reserva> Reservas { get; set; }
        public DbSet<Renting.BaseLine.Domain.Entities.TipoVehiculo> TipoVehiculos { get; set; }
        public DbSet<Renting.BaseLine.Domain.Entities.Cliente> Clientes { get; set; }
        public DbSet<Renting.BaseLine.Domain.Entities.EstadoReserva> EstadoReservas { get; set; }
    }
}
