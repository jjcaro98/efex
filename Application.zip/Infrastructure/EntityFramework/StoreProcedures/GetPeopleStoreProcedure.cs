﻿using System.Data;
using Renting.BaseLine.Infrastructure.EntityFramework.Helpers;

namespace Renting.BaseLine.Infrastructure.EntityFramework.StoreProcedures
{
    public class GetPeopleStoreProcedure
    {
        [SqlParameter("first_name")]
        public string FirstName { get; set; } = string.Empty;

        [SqlParameter("last_name")]
        public string LastName { get; set; } = string.Empty;

        [SqlParameter("count_prueba", Direction = ParameterDirection.Output)]
        public int Count { get; set; }
    }
}
