﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Serilog.Exceptions;

namespace Renting.BaseLine.Infrastructure.Logger
{
    [ExcludeFromCodeCoverage]
    public static class RentingLoggerExtensions
    {
        public static IServiceCollection AddRentingLogger(this IServiceCollection services, IConfiguration configuration)
        {
            ConfigureLogger(configuration);

            services.AddSingleton(Log.Logger);

            return services;
        }

        private static void ConfigureLogger(IConfiguration configuration)
        {
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .Enrich.FromLogContext()
                .Enrich.WithExceptionDetails()
                .Enrich.WithMachineName()
                .WriteTo.Debug()
                .WriteTo.Console()
                .WriteTo.ApplicationInsights(configuration["ApplicationInsights:ConnectionString"], TelemetryConverter.Traces)
                .CreateLogger();
        }
    }
}
