﻿namespace Renting.BaseLine.Infrastructure.ServiceBus
{
    public record Message(string Type, string Content);
}
