﻿using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Options;
using Renting.BaseLine.Application.Services;

namespace Renting.BaseLine.Infrastructure.ServiceBus
{
    public class MessageService : IMessageService
    {
        private readonly IOptions<ServiceBusOptions> _options;
        private readonly ServiceBusClient _client;

        public MessageService(IOptions<ServiceBusOptions> options)
        {
            _options = options;
            _client = new ServiceBusClient(_options.Value.Endpoint);
        }

        public async Task SendAsync<T>(object content, int index = 0)
        {
            var sender = _client.CreateSender(_options.Value.Queues[index]);
            var message = JsonSerializer.Serialize(new Message(typeof(T).Name, JsonSerializer.Serialize(content)));

            await sender.SendMessageAsync(new ServiceBusMessage(message));
        }
    }
}
