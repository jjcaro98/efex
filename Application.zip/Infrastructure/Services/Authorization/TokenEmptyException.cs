﻿namespace Renting.BaseLine.Infrastructure.Services.Authorization
{

    [Serializable]
    public class TokenEmptyException : Exception
    {
        public TokenEmptyException() { }
        public TokenEmptyException(string message) : base(message) { }
        public TokenEmptyException(string message, Exception inner) : base(message, inner) { }
        protected TokenEmptyException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
