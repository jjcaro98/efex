﻿using Renting.BaseLine.Application.Services.Notifications;
using System.Text.Json.Serialization;

namespace Renting.BaseLine.Infrastructure.Services.Notifications
{
    public class EmailRequest
    {
        [JsonPropertyName("sender")]
        public EmailUserNameRequest? Sender { get; set; }

        [JsonPropertyName("recipients")]
        public List<EmailUserNameRequest>? Recipients { get; set; }

        [JsonPropertyName("subject")]
        public string? Subject { get; set; }

        [JsonPropertyName("body")]
        public string? Body { get; set; }
    }
}
