﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace PruebaTecnica.Application.People.DeletePerson
{
    public record DeletePersonCommand(
     [Required] int Id
     ) : IRequest;
}
