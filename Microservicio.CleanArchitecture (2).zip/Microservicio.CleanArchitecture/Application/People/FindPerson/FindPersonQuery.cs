﻿using System.ComponentModel.DataAnnotations;
using MediatR;
using PruebaTecnica.Application.People.Shared;

namespace PruebaTecnica.Application.People.FindPerson
{
    public record FindPersonQuery([Required] int Id) : IRequest<PersonDto>;
}
