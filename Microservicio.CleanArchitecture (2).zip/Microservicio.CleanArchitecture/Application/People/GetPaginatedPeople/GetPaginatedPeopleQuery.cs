﻿using MediatR;
using PruebaTecnica.Application.People.Shared;
using PruebaTecnica.Domain.Repositories;

namespace PruebaTecnica.Application.People.GetPaginatedPeople
{
    public record GetPaginatedPeopleQuery(int PageIndex, int PageSize) : IRequest<IPaginatedResult<PersonDto>>;
}
