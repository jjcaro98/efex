﻿using AutoMapper;
using MediatR;
using PruebaTecnica.Application.People.Shared;
using PruebaTecnica.Domain.Repositories;
using PruebaTecnica.Domain.Repositories.Criteria;

namespace PruebaTecnica.Application.People.GetPaginatedPeopleByStoredProcedure
{
    public class GetPaginatedPeopleByStoredProcedureHandler : IRequestHandler<GetPaginatedPeopleByStoredProcedureQuery, IPaginatedResult<PersonDto>>
    {
        private readonly IPeopleSPRepository _repository;
        private readonly IMapper _mapper;

        public GetPaginatedPeopleByStoredProcedureHandler(IPeopleSPRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<IPaginatedResult<PersonDto>> Handle(GetPaginatedPeopleByStoredProcedureQuery request, CancellationToken cancellationToken)
        {
            var result = await _repository.GetPeoplePaginatedAsync(_mapper.Map<PeopleSPCriteria>(request));

            return result.CreateFrom(_mapper.Map<IEnumerable<PersonDto>>(result.Items));
        }
    }
}
