﻿using MediatR;
using PruebaTecnica.Application.People.Shared;
using PruebaTecnica.Domain.Repositories;

namespace PruebaTecnica.Application.People.GetPaginatedPeopleByStoredProcedure
{
    public record GetPaginatedPeopleByStoredProcedureQuery(
        int PageIndex,
        int PageSize) : IRequest<IPaginatedResult<PersonDto>>;
}
