﻿using AutoMapper;
using PruebaTecnica.Application.People.CreatePeople;
using PruebaTecnica.Application.People.CreatePerson;
using PruebaTecnica.Application.People.GetPaginatedPeopleByStoredProcedure;
using PruebaTecnica.Application.People.Shared;
using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Domain.Repositories.Criteria;

namespace PruebaTecnica.Application.People
{
    public class PersonProfile : Profile
    {
        public PersonProfile()
        {
            CreateMap<CreatePersonCommand, Person>();
            CreateMap<CreatePeopleCommand.Person, CreatePersonCommand>();
            CreateMap<Person, PersonDto>();
            CreateMap<GetPaginatedPeopleByStoredProcedureQuery, PeopleSPCriteria>();
            CreateMap<PeopleSP, PersonDto>();
        }
    }
}
