﻿using System.ComponentModel.DataAnnotations;
using MediatR;

namespace PruebaTecnica.Application.People.SendCreatePeople
{
    public class SendCreatePeopleCommand : List<SendCreatePeopleCommand.Person>, IRequest
    {
        public record Person(
            [Required] string FirstName,
            [Required] string LastName,
            [Required] string Email,
            [Required] DateTime? DateOfBirth);
    }
}
