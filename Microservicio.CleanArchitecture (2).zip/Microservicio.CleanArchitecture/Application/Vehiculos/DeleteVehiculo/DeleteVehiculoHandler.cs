using Domain.Repositories;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Vehiculos.DeleteVehiculo
{
    public class DeleteVehiculoHandler : IRequestHandler<DeleteVehiculoCommand, Unit>
    {
        private readonly IVehiculoRepository _vehiculoRepository;
        public DeleteVehiculoHandler(IVehiculoRepository vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<Unit> Handle(DeleteVehiculoCommand request, CancellationToken cancellationToken)
        {
            await _vehiculoRepository.DeleteAsync(request.IdVehiculo);
            return Unit.Value;
        }
    }
}
