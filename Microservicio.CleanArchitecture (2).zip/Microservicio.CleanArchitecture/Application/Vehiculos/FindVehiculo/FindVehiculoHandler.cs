using Application.Vehiculos.Shared;
using Domain.Repositories;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Vehiculos.FindVehiculo
{
    public class FindVehiculoHandler : IRequestHandler<FindVehiculoQuery, VehiculoDto>
    {
        private readonly IVehiculoRepository _vehiculoRepository;
        public FindVehiculoHandler(IVehiculoRepository vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<VehiculoDto> Handle(FindVehiculoQuery request, CancellationToken cancellationToken)
        {
            var v = await _vehiculoRepository.GetByIdAsync(request.IdVehiculo);
            if (v == null) return null;
            return new VehiculoDto
            {
                IdVehiculo = v.IdVehiculo,
                Placa = v.Placa,
                Marca = v.Marca,
                Modelo = v.Modelo,
                Anio = v.Anio,
                IdTipoVehiculo = v.IdTipoVehiculo,
                TipoDescripcion = v.TipoVehiculo?.Descripcion,
                IdEstadoVehiculo = v.IdEstadoVehiculo,
                EstadoDescripcion = v.EstadoVehiculo?.Descripcion
            };
        }
    }
}
