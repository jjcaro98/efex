using Application.Vehiculos.Shared;
using MediatR;

namespace Application.Vehiculos.FindVehiculo
{
    public class FindVehiculoQuery : IRequest<VehiculoDto>
    {
        public int IdVehiculo { get; set; }
    }
}
