using Domain.Entities;
using Domain.Repositories;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Vehiculos.UpdateVehiculo
{
    public class UpdateVehiculoHandler : IRequestHandler<UpdateVehiculoCommand, Unit>
    {
        private readonly IVehiculoRepository _vehiculoRepository;
        public UpdateVehiculoHandler(IVehiculoRepository vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<Unit> Handle(UpdateVehiculoCommand request, CancellationToken cancellationToken)
        {
            var vehiculo = await _vehiculoRepository.GetByIdAsync(request.IdVehiculo);
            if (vehiculo == null)
                throw new Exception("Vehiculo not found");

            vehiculo.Placa = request.Placa;
            vehiculo.Marca = request.Marca;
            vehiculo.Modelo = request.Modelo;
            vehiculo.Anio = request.Anio;
            vehiculo.IdTipoVehiculo = request.IdTipoVehiculo;
            vehiculo.IdEstadoVehiculo = request.IdEstadoVehiculo;

            await _vehiculoRepository.UpdateAsync(vehiculo);
            return Unit.Value;
        }
    }
}
