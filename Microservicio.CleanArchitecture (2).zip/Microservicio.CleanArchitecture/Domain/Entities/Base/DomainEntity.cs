﻿namespace PruebaTecnica.Domain.Entities.Base
{
    public class DomainEntity
    {

    }
}
