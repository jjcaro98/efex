namespace Domain.Entities
{
    public class EstadoVehiculo
    {
        public int IdEstadoVehiculo { get; set; }
        public string Descripcion { get; set; }
    }
}
