﻿using PruebaTecnica.Domain.Entities.Base;

namespace PruebaTecnica.Domain.Entities
{
    public class PeopleSP : DomainEntity
    {
        public string FirstName { get; set; } = default!;

        public string LastName { get; set; } = default!;

        public string Email { get; set; } = default!;

        public DateTime DateOfBirth { get; set; }
    }
}
