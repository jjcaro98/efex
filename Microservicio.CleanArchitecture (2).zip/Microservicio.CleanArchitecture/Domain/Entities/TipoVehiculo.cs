public class TipoVehiculo
{
    public int IdTipoVehiculo { get; set; }
    public string Descripcion { get; set; }
}