﻿using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Domain.Repositories.Criteria;

namespace PruebaTecnica.Domain.Repositories
{
    public interface IPeopleSPRepository : IRepository<PeopleSP>
    {
        Task<IPaginatedResult<PeopleSP>> GetPeoplePaginatedAsync(PeopleSPCriteria criteria);
    }
}
