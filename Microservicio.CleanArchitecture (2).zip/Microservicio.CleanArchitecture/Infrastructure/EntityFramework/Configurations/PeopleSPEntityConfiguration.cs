﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.EntityFramework.Configurations
{
    public class PeopleSPEntityConfiguration : IEntityTypeConfiguration<PeopleSP>
    {
        public void Configure(EntityTypeBuilder<PeopleSP> builder)
        {
            builder.HasNoKey();

            builder.Property(x => x.FirstName)
                .IsRequired();

            builder.Property(x => x.LastName)
                .IsRequired();
        }
    }
}
