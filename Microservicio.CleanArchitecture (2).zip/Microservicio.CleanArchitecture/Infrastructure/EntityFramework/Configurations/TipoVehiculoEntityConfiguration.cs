using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace PruebaTecnica.Infrastructure.EntityFramework.Configurations
{
    public class TipoVehiculoEntityConfiguration : IEntityTypeConfiguration<TipoVehiculo>
    {
        public void Configure(EntityTypeBuilder<TipoVehiculo> builder)
        {
            builder.ToTable("TipoVehiculo");
            builder.HasKey(e => e.IdTipoVehiculo);
            builder.Property(e => e.IdTipoVehiculo).ValueGeneratedOnAdd();
            builder.Property(e => e.Descripcion).IsRequired().HasMaxLength(100);
        }
    }
}
