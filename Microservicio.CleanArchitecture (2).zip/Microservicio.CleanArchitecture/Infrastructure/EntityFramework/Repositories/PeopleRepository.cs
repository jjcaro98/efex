﻿using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Domain.Repositories;
using PruebaTecnica.Infrastructure.EntityFramework.StoreProcedures;

namespace PruebaTecnica.Infrastructure.EntityFramework.Repositories
{
    public class PeopleRepository : Repository<Person>, IPeopleRepository
    {
        public PeopleRepository(PersistenceContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Person>> GetPeopleAsync(object instance)
        {
            var result = await ExecuteStoreProcedureAsync<GetPeopleStoreProcedure>("Prueba", instance);

            return result.Items;
        }

        public async Task<IEnumerable<Person>> GetPeopleAsync(string firstName, string lastName)
        {
            var definition = new GetPeopleStoreProcedure { FirstName = firstName, LastName = lastName };
            var result = await ExecuteStoreProcedureAsync("dbo.Prueba", definition);

            return result.Items;
        }

        public async Task<IPaginatedResult<Person>> GetPeoplePaginatedAsync(int pageIndex, int pageSize)
        {
            var definition = new GetPeoplePaginatedStoreProcedure { PageIndex = pageIndex, PageSize = pageSize };
            var result = await ExecuteStoreProcedureAsync("dbo.Prueba", definition);

            return new PaginatedResult<Person>(pageIndex, pageSize, (int)result.OutputValues["TotalCount"], result.Items);
        }
    }
}
