using Domain.Entities;
using Domain.Repositories;
using PruebaTecnica.Infrastructure.EntityFramework;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaTecnica.Infrastructure.EntityFramework.Repositories
{
    public class VehiculoRepository : IVehiculoRepository
    {
        private readonly PersistenceContext _context;
        public VehiculoRepository(PersistenceContext context)
        {
            _context = context;
        }

        public async Task AddAsync(Vehiculo vehiculo)
        {
            _context.Vehiculos.Add(vehiculo);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var vehiculo = await _context.Vehiculos.FindAsync(id);
            if (vehiculo != null)
            {
                _context.Vehiculos.Remove(vehiculo);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Vehiculo>> GetAllAsync()
        {
            return await _context.Vehiculos
                .Include(v => v.EstadoVehiculo)
                .Include(v => v.TipoVehiculo)
                .ToListAsync();
        }

        public async Task<Vehiculo> GetByIdAsync(int id)
        {
            return await _context.Vehiculos
                .Include(v => v.EstadoVehiculo)
                .Include(v => v.TipoVehiculo)
                .FirstOrDefaultAsync(v => v.IdVehiculo == id);
        }

        public async Task<Vehiculo> GetByPlacaAsync(string placa)
        {
            return await _context.Vehiculos.FirstOrDefaultAsync(v => v.Placa == placa);
        }

        public async Task UpdateAsync(Vehiculo vehiculo)
        {
            _context.Vehiculos.Update(vehiculo);
            await _context.SaveChangesAsync();
        }
    }
}
