﻿using System.Text.Json.Serialization;
using PruebaTecnica.Application.Services.Notifications;

namespace PruebaTecnica.Infrastructure.Services.Notifications
{
    public class EmailUserNameRequest
    {
        [JsonPropertyName("email")]
        public string? Email { get; set; }

        [JsonPropertyName("userName")]
        public string? UserName { get; set; }

        public static EmailUserNameRequest From(EmailUserName emailUserName)
            => new() { Email = emailUserName.Email, UserName = emailUserName.UserName };

        public static List<EmailUserNameRequest> From(IEnumerable<EmailUserName> emailUserNames)
            => emailUserNames.Select(p => new EmailUserNameRequest { Email = p.Email, UserName = p.UserName })
                .ToList();
    }
}
