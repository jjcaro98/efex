namespace WebApi.Controllers.Responses
{
    public static class VehiculoMessages
    {
        public const string VehiculosObtenidos = "Vehículos obtenidos correctamente";
        public const string VehiculoObtenido = "Vehículo obtenido correctamente";
        public const string VehiculoCreado = "Vehículo creado correctamente";
        public const string VehiculoActualizado = "Vehículo actualizado correctamente";
        public const string VehiculoEliminado = "Vehículo eliminado correctamente";
        public const string VehiculoNoEncontrado = "Vehículo no encontrado";
        public const string ErrorObtenerVehiculos = "Hubo un error al obtener los vehículos";
        public const string ErrorObtenerVehiculo = "Hubo un error al obtener el vehículo";
        public const string ErrorCrearVehiculo = "Hubo un error al crear el vehículo";
        public const string ErrorActualizarVehiculo = "Hubo un error al actualizar el vehículo";
        public const string ErrorEliminarVehiculo = "Hubo un error al eliminar el vehículo";
        public const string IdUrlNoCoincide = "El id de la URL no coincide con el del vehículo";
    }
}
