﻿using System.Reflection;
using System.Text.Json;
using MediatR;

namespace Renting.BaseLine.Worker.Base
{
    public class MessageResolverService
    {
        private readonly Dictionary<string, Type> _messageTypes;

        public MessageResolverService()
        {
            var requestType = typeof(IRequest);

            _messageTypes = Assembly.Load("Application")
                .GetTypes()
                .Where(t => requestType.IsAssignableFrom(t))
                .ToDictionary(t => t.Name, t => t);
        }

        public object? Resolve(string typeName, string content)
        {
            if (!_messageTypes.TryGetValue(typeName, out var type))
            {
                throw new ArgumentException($"No se encontró un tipo de mensaje para {typeName}");
            }

            return JsonSerializer.Deserialize(content, type);
        }
    }
}
