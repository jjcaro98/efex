﻿using System.ComponentModel.DataAnnotations;
using MediatR;
using PruebaTecnica.Application.People.Shared;

namespace PruebaTecnica.Application.People.GetPeople
{
    public record GetPeopleQuery() : IRequest<IEnumerable<PersonDto>>;
}
