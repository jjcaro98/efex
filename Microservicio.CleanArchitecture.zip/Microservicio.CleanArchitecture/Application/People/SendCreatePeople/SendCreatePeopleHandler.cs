﻿using MediatR;
using PruebaTecnica.Application.People.CreatePeople;
using PruebaTecnica.Application.Services;

namespace PruebaTecnica.Application.People.SendCreatePeople
{
    public class SendCreatePeopleHandler : IRequestHandler<SendCreatePeopleCommand>
    {
        private readonly IMessageService _messageService;

        public SendCreatePeopleHandler(IMessageService messageService)
        {
            _messageService = messageService;
        }

        public async Task Handle(SendCreatePeopleCommand request, CancellationToken cancellationToken)
        {
            await _messageService.SendAsync<CreatePeopleCommand>(request);
        }
    }
}
