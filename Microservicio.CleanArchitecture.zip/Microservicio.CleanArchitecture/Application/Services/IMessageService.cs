﻿namespace PruebaTecnica.Application.Services
{
    public interface IMessageService
    {
        public const int Base = 0;

        Task SendAsync<T>(object content, int index = 0);
    }
}
