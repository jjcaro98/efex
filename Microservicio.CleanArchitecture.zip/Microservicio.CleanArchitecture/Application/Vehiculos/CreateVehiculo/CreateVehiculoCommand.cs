using MediatR;

namespace Application.Vehiculos.CreateVehiculo
{
    public class CreateVehiculoCommand : IRequest<int>
    {
        public string Placa { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Anio { get; set; }
        public int IdTipoVehiculo { get; set; }
        public int IdEstadoVehiculo { get; set; }
    }
}
