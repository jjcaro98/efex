using Domain.Entities;
using Domain.Repositories;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Vehiculos.CreateVehiculo
{
    public class CreateVehiculoHandler : IRequestHandler<CreateVehiculoCommand, int>
    {
        private readonly IVehiculoRepository _vehiculoRepository;
        public CreateVehiculoHandler(IVehiculoRepository vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<int> Handle(CreateVehiculoCommand request, CancellationToken cancellationToken)
        {
            var vehiculo = new Vehiculo
            {
                Placa = request.Placa,
                Marca = request.Marca,
                Modelo = request.Modelo,
                Anio = request.Anio,
                IdTipoVehiculo = request.IdTipoVehiculo,
                IdEstadoVehiculo = request.IdEstadoVehiculo
            };
            await _vehiculoRepository.AddAsync(vehiculo);
            return vehiculo.IdVehiculo;
        }
    }
}
