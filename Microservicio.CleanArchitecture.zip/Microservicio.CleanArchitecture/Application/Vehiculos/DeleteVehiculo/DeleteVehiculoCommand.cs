using MediatR;

namespace Application.Vehiculos.DeleteVehiculo
{
    public class DeleteVehiculoCommand : IRequest<Unit>
    {
        public int IdVehiculo { get; set; }
    }
}
