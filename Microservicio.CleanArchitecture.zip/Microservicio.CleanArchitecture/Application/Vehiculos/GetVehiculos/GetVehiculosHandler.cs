using Application.Vehiculos.Shared;
using Domain.Repositories;
using MediatR;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Vehiculos.GetVehiculos
{
    public class GetVehiculosHandler : IRequestHandler<GetVehiculosQuery, IEnumerable<VehiculoDto>>
    {
        private readonly IVehiculoRepository _vehiculoRepository;
        public GetVehiculosHandler(IVehiculoRepository vehiculoRepository)
        {
            _vehiculoRepository = vehiculoRepository;
        }

        public async Task<IEnumerable<VehiculoDto>> Handle(GetVehiculosQuery request, CancellationToken cancellationToken)
        {
            var vehiculos = await _vehiculoRepository.GetAllAsync();
            return vehiculos.Select(v => new VehiculoDto
            {
                IdVehiculo = v.IdVehiculo,
                Placa = v.Placa,
                Marca = v.Marca,
                Modelo = v.Modelo,
                Anio = v.Anio,
                IdTipoVehiculo = v.IdTipoVehiculo,
                TipoDescripcion = v.TipoVehiculo?.Descripcion,
                IdEstadoVehiculo = v.IdEstadoVehiculo,
                EstadoDescripcion = v.EstadoVehiculo?.Descripcion
            });
        }
    }
}
