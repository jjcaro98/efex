using Application.Vehiculos.Shared;
using MediatR;
using System.Collections.Generic;

namespace Application.Vehiculos.GetVehiculos
{
    public class GetVehiculosQuery : IRequest<IEnumerable<VehiculoDto>>
    {
    }
}
