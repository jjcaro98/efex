namespace Application.Vehiculos.Shared
{
    public class VehiculoDto
    {
        public int IdVehiculo { get; set; }
        public required string Placa { get; set; }
        public required string Marca { get; set; }
        public required string Modelo { get; set; }
        public int Anio { get; set; }
        public int IdTipoVehiculo { get; set; }
        public required string TipoDescripcion { get; set; }
        public int IdEstadoVehiculo { get; set; }
        public required string EstadoDescripcion { get; set; }
    }
}
