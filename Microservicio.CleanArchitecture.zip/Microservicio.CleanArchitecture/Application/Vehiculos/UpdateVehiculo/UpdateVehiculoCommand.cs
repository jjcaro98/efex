using MediatR;

namespace Application.Vehiculos.UpdateVehiculo
{
    public class UpdateVehiculoCommand : IRequest<Unit>
    {
        public int IdVehiculo { get; set; }
        public string Placa { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Anio { get; set; }
        public int IdTipoVehiculo { get; set; }
        public int IdEstadoVehiculo { get; set; }
    }
}
