﻿namespace PruebaTecnica.Domain.Repositories.Criteria
{
    public class PeopleSPCriteria
    {
        public int PageIndex { get; set; }

        public int PageSize { get; set; }
    }
}
