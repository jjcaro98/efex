﻿using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Domain.Repositories
{
    public interface IPeopleRepository : IRepository<Person>
    {
        Task<IEnumerable<Person>> GetPeopleAsync(object instance);
        Task<IEnumerable<Person>> GetPeopleAsync(string firstName, string lastName);
    }
}
