using Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Domain.Repositories
{
    public interface IVehiculoRepository
    {
        Task<Vehiculo> GetByIdAsync(int id);
        Task<IEnumerable<Vehiculo>> GetAllAsync();
        Task AddAsync(Vehiculo vehiculo);
        Task UpdateAsync(Vehiculo vehiculo);
        Task DeleteAsync(int id);
        Task<Vehiculo> GetByPlacaAsync(string placa);
    }
}
