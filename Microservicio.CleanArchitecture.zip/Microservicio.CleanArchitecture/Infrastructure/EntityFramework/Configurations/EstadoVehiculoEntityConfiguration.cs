using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace PruebaTecnica.Infrastructure.EntityFramework.Configurations
{
    public class EstadoVehiculoEntityConfiguration : IEntityTypeConfiguration<EstadoVehiculo>
    {
        public void Configure(EntityTypeBuilder<EstadoVehiculo> builder)
        {
            builder.ToTable("EstadoVehiculo");
            builder.HasKey(e => e.IdEstadoVehiculo);
            builder.Property(e => e.IdEstadoVehiculo).ValueGeneratedOnAdd();
            builder.Property(e => e.Descripcion).IsRequired().HasMaxLength(50);
        }
    }
}
