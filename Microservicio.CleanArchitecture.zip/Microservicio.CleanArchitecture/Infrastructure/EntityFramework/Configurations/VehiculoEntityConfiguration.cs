using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace PruebaTecnica.Infrastructure.EntityFramework.Configurations
{
    public class VehiculoEntityConfiguration : IEntityTypeConfiguration<Vehiculo>
    {
        public void Configure(EntityTypeBuilder<Vehiculo> builder)
        {
            builder.ToTable("Vehiculo");
            builder.HasKey(v => v.IdVehiculo);
            builder.Property(v => v.IdVehiculo).ValueGeneratedOnAdd();
            builder.Property(v => v.Placa).IsRequired().HasMaxLength(20);
            builder.Property(v => v.Marca).IsRequired().HasMaxLength(50);
            builder.Property(v => v.Modelo).IsRequired().HasMaxLength(50);
            builder.Property(v => v.Anio).IsRequired();
            builder.Property(v => v.IdTipoVehiculo).IsRequired();
            builder.Property(v => v.IdEstadoVehiculo).IsRequired();

            builder.HasOne(v => v.EstadoVehiculo)
                .WithMany()
                .HasForeignKey(v => v.IdEstadoVehiculo)
                .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(v => v.TipoVehiculo)
                .WithMany()
                .HasForeignKey(v => v.IdTipoVehiculo)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
