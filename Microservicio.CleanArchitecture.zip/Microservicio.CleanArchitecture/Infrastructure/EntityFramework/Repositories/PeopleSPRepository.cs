﻿using Microsoft.Extensions.Configuration;
using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Domain.Repositories;
using PruebaTecnica.Domain.Repositories.Criteria;
using PruebaTecnica.Infrastructure.EntityFramework.Helpers;
using PruebaTecnica.Infrastructure.EntityFramework.StoreProcedures;

namespace PruebaTecnica.Infrastructure.EntityFramework.Repositories
{
    public class PeopleSPRepository : Repository<PeopleSP>, IPeopleSPRepository
    {
        private readonly IConfiguration _configuration;

        public PeopleSPRepository(PersistenceContext context, IConfiguration configuration) : base(context)
        {
            _configuration = configuration;
        }

        public async Task<IPaginatedResult<PeopleSP>> GetPeoplePaginatedAsync(PeopleSPCriteria criteria)
        {
            var storedProcedure = _configuration["StoredProcedures:GetPeopleInformationSP"];
            var result = await ExecuteStoreProcedureAsync<GetPeoplePaginatedStoreProcedure>(storedProcedure!, criteria);
            var paginatedResult = new PaginatedResult<PeopleSP>(criteria.PageIndex, criteria.PageSize, result.OutputValues.GetValue<int>("TotalCount"), result.Items);
            return paginatedResult;
        }
    }
}
