﻿using System.Data;
using PruebaTecnica.Infrastructure.EntityFramework.Helpers;

namespace PruebaTecnica.Infrastructure.EntityFramework.StoreProcedures
{
    public class GetPeopleStoreProcedure
    {
        [SqlParameter("first_name")]
        public string FirstName { get; set; } = string.Empty;

        [SqlParameter("last_name")]
        public string LastName { get; set; } = string.Empty;

        [SqlParameter("count_prueba", Direction = ParameterDirection.Output)]
        public int Count { get; set; }
    }
}
