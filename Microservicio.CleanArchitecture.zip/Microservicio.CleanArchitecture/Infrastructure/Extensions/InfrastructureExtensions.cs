﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PruebaTecnica.Application.Services;
using PruebaTecnica.Application.Services.Notifications;
using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Domain.Repositories;
using PruebaTecnica.Infrastructure.EntityFramework;
using PruebaTecnica.Infrastructure.EntityFramework.Repositories;
using PruebaTecnica.Infrastructure.ServiceBus;
using PruebaTecnica.Infrastructure.Services.Authorization;
using PruebaTecnica.Infrastructure.Services.Notifications;
using Domain.Repositories;

namespace PruebaTecnica.Infrastructure.Extensions
{
    public static class InfrastructureExtensions
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            AddOptions(services, configuration);
            AddHttpClients(services, configuration);
            AddSqlServer(services, configuration);

            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IRepository<Person>, Repository<Person>>();
            services.AddScoped<IPeopleRepository, PeopleRepository>();
            services.AddScoped<IPeopleSPRepository, PeopleSPRepository>();
            services.AddScoped<IVehiculoRepository, PruebaTecnica.Infrastructure.EntityFramework.Repositories.VehiculoRepository>();
            services.AddSingleton<IMessageService, MessageService>();
            services.AddSingleton<INotificationService, NotificationService>();
            services.AddSingleton<AuthorizationService>();

            return services;
        }

        private static void AddHttpClients(IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClient("Authorization", client =>
            {
                client.BaseAddress = new Uri(configuration["Services:Authorization:BaseAddress"]!);
            });
            services.AddHttpClient("Notifications", client =>
            {
                client.BaseAddress = new Uri(configuration["Services:Notifications:BaseAddress"]!);
            });
        }

        private static void AddOptions(IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<ServiceBusOptions>(configuration.GetSection(ServiceBusOptions.Key).Bind);
        }

        private static void AddSqlServer(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<PersistenceContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("Base"),
                    sqlServerOptionsAction =>
                    {
                        sqlServerOptionsAction.MigrationsHistoryTable("__MicroMigrationHistory", configuration.GetConnectionString("BaseSchema"));
                    });

                options.ConfigureWarnings(warnings =>
                {
                    warnings.Default(WarningBehavior.Log);
                });
            });
        }
    }
}
