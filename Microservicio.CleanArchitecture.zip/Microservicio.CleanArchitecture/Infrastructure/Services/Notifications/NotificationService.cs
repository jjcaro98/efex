﻿using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PruebaTecnica.Application.Services.Notifications;
using PruebaTecnica.Infrastructure.Services.Authorization;

namespace PruebaTecnica.Infrastructure.Services.Notifications
{
    public class NotificationService : BaseService, INotificationService
    {
        private readonly AuthorizationService _authorizationService;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public NotificationService(AuthorizationService authorizationService,
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration,
            ILogger<NotificationService> logger) : base(configuration, logger)
        {
            _authorizationService = authorizationService;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        public async Task SendAsync(EmailUserName sender, IEnumerable<EmailUserName> recipients, string title, string content)
        {
            var client = _httpClientFactory.CreateClient("Notifications");

            client.DefaultRequestHeaders.Authorization = new("Bearer", await _authorizationService.GetTokenAsync());

            var email = new EmailRequest
            {
                Sender = EmailUserNameRequest.From(sender),
                Recipients = EmailUserNameRequest.From(recipients),
                Subject = title,
                Body = content,
            };

            await ExecuteAndRetryAsync(async () =>
            {
                var response = await client.PostAsJsonAsync(_configuration["Services:Notifications:SendEmail:RequestUri"], email);

                response?.EnsureSuccessStatusCode();
            });
        }
    }
}
