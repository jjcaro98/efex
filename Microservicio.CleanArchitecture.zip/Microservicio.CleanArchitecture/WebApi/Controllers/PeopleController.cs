﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.People.CreatePerson;
using PruebaTecnica.Application.People.DeletePerson;
using PruebaTecnica.Application.People.FindPerson;
using PruebaTecnica.Application.People.GetPaginatedPeople;
using PruebaTecnica.Application.People.GetPaginatedPeopleByStoredProcedure;
using PruebaTecnica.Application.People.GetPeople;
using PruebaTecnica.Application.People.SendCreatePeople;
using PruebaTecnica.Application.People.Shared;
using PruebaTecnica.Application.People.UpdatePerson;
using PruebaTecnica.Domain.Repositories;

namespace PruebaTecnica.WebApi.Controllers
{
    [Route("api/people")]
    [ApiController]
    [Authorize]
    public class PeopleController : ControllerBase
    {
        private readonly IMediator _mediator;

        public PeopleController(IMediator mediator) => _mediator = mediator;

        /// <summary>Obtener una persona por Id</summary>
        /// <param name="id">Id del regisro a buscar</param>
        /// <returns>Retorna el registro de la persona soliciada</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PersonDto))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<PersonDto> FindAsync(int id) => await _mediator.Send(new FindPersonQuery(id));

        /// <summary>Obtiene los datos de las personas</summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<PersonDto>), 200)]
        public async Task<IEnumerable<PersonDto>> GetAsync() => await _mediator.Send(new GetPeopleQuery());

        /// <summary>Crea un nuevo registro de persona</summary>
        /// <param name="person"></param>
        /// <returns></returns>
        [HttpPost("CreatePeople")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task CreateAsync(CreatePersonCommand person) => await _mediator.Send(person);

        /// <summary>Recibe gran cantidad de datos, para ser procesados en segundo plano</summary>
        /// <param name="people"></param>
        /// <returns></returns>
        [HttpPost("bulk")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public async Task CreateBulkAsync(SendCreatePeopleCommand people) => await _mediator.Send(people);

        /// <summary>Actualiza los datos de una persona</summary>
        /// <param name="person">Los datos de la persona a actualizar</param>
        /// <returns></returns>
        [HttpPut("EditPeople")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public async Task UpdatePerson(UpdatePersonCommand person) => await _mediator.Send(person);

        /// <summary>Eliminar una persona por Id</summary>
        /// <param name="id">Id del regisro a eliminar</param>
        /// <returns></returns>
        [HttpDelete("DeletePeople")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public async Task DeletePerson(int id) => await _mediator.Send(new DeletePersonCommand(id));

        /// <summary>Obtener una lista paginada de personas</summary>
        /// <param name="pageIndex">Página Actual</param>
        /// <param name="pageSize">Cantidad de registros por página</param>
        /// <returns>Retorna la informaciónd de personas paginada</returns>
        [HttpGet("GetPaginatedPeople")]
        [ProducesResponseType(typeof(IEnumerable<PersonDto>), 200)]
        public async Task<IPaginatedResult<PersonDto>> GetPaginatedAsync(int pageIndex = 0, int pageSize = 10)
        {
            return await _mediator.Send(new GetPaginatedPeopleQuery(pageIndex, pageSize));
        }

        /// <summary>Obtener una lista paginada de personas</summary>
        /// <param name="pageIndex">Página Actual</param>
        /// <param name="pageSize">Cantidad de registros por página</param>
        /// <returns>Retorna la informaciónd de personas paginada</returns>
        [HttpGet("GetPaginatedPeopleByStoredProcedure")]
        [ProducesResponseType(typeof(IEnumerable<PersonDto>), 200)]
        [ProducesResponseType(401)]
        [ProducesResponseType(404)]
        public async Task<IPaginatedResult<PersonDto>> GetPaginatedByStoredProcedureAsycn(int pageIndex = 1, int pageSize = 10)
        {
            return await _mediator.Send(new GetPaginatedPeopleByStoredProcedureQuery(pageIndex, pageSize));
        }
    }
}
