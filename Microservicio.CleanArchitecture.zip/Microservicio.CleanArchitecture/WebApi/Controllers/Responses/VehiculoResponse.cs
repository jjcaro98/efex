using Application.Vehiculos.Shared;
using System.Collections.Generic;

namespace WebApi.Controllers.Responses
{
    public class VehiculoResponse
    {
        public required string Message { get; set; }
        public required VehiculoDto Data { get; set; }
    }

    public class VehiculoListResponse
    {
        public required string Message { get; set; }
        public required IEnumerable<VehiculoDto> Data { get; set; }
    }

    public class VehiculoIdResponse
    {
        public required string Message { get; set; }
        public int Id { get; set; }
    }

    public class ErrorResponse
    {
        public required string Message { get; set; }
    }
}
