using Application.Vehiculos.CreateVehiculo;
using Application.Vehiculos.DeleteVehiculo;
using Application.Vehiculos.FindVehiculo;
using Application.Vehiculos.GetVehiculos;
using Application.Vehiculos.Shared;
using Application.Vehiculos.UpdateVehiculo;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Controllers.Responses;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehiculosController : ControllerBase
    {
        private readonly IMediator _mediator;
        public VehiculosController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VehiculoListResponse))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ErrorResponse))]
        public async Task<IActionResult> Get()
        {
            try
            {
                var vehiculos = await _mediator.Send(new GetVehiculosQuery());
                return Ok(new VehiculoListResponse { Message = VehiculoMessages.VehiculosObtenidos, Data = vehiculos });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ErrorResponse { Message = $"Hubo un error al obtener los vehículos: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VehiculoResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ErrorResponse))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ErrorResponse))]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var vehiculo = await _mediator.Send(new FindVehiculoQuery { IdVehiculo = id });
                if (vehiculo == null) return NotFound(new ErrorResponse { Message = VehiculoMessages.VehiculoNoEncontrado });
                return Ok(new VehiculoResponse { Message = VehiculoMessages.VehiculoObtenido, Data = vehiculo });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ErrorResponse { Message = $"Hubo un error al obtener el vehículo: {ex.Message}" });
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VehiculoIdResponse))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ErrorResponse))]
        public async Task<IActionResult> Post([FromBody] CreateVehiculoCommand command)
        {
            try
            {
                var id = await _mediator.Send(command);
                return Ok(new VehiculoIdResponse { Message = VehiculoMessages.VehiculoCreado, Id = id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ErrorResponse { Message = $"Hubo un error al crear el vehículo: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ErrorResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ErrorResponse))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ErrorResponse))]
        public async Task<IActionResult> Put(int id, [FromBody] UpdateVehiculoCommand command)
        {
            if (id != command.IdVehiculo) return BadRequest(new ErrorResponse { Message = VehiculoMessages.IdUrlNoCoincide });
            try
            {
                await _mediator.Send(command);
                return Ok(new ErrorResponse { Message = VehiculoMessages.VehiculoActualizado });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ErrorResponse { Message = $"Hubo un error al actualizar el vehículo: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ErrorResponse))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ErrorResponse))]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _mediator.Send(new DeleteVehiculoCommand { IdVehiculo = id });
                return Ok(new ErrorResponse { Message = VehiculoMessages.VehiculoEliminado });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ErrorResponse { Message = $"Hubo un error al eliminar el vehículo: {ex.Message}" });
            }
        }
    }
}
