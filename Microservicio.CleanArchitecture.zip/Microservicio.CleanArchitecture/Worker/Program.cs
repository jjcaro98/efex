﻿using Renting.BaseLine.Infrastructure.Extensions;
using Renting.BaseLine.Infrastructure.Logger;
using Renting.BaseLine.Worker;
using Renting.BaseLine.Worker.Base;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureLogging((context, logging) =>
    {
        logging.AddRentingLogger(context.Configuration);
    })
    .ConfigureServices((context, services) =>
    {
        var configuration = context.Configuration;

        services.AddHostedService<Worker>();
        services.AddSingleton<MessageResolverService>();
        services.AddApplication(configuration);
        services.AddInfrastructure(configuration);
    })
    .Build();

host.Run();
