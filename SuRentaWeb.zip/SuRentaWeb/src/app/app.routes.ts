import { Routes } from '@angular/router';
import { VehiculoComponent } from './componentes/vehiculos/vehiculo.component';
import { ReservaComponent } from './componentes/reservas/reserva.component';
import { ClienteComponent } from './componentes/clientes/cliente.component';

export const routes: Routes = [
  { path: 'vehiculos', component: VehiculoComponent, pathMatch: 'full' },
  { path: 'reservas', component: ReservaComponent, pathMatch: 'full' },
  { path: 'clientes', component: ClienteComponent, pathMatch: 'full' },

  { path: '', redirectTo: 'vehiculos', pathMatch: 'full' },
  { path: '**', redirectTo: 'vehiculos' }
];
