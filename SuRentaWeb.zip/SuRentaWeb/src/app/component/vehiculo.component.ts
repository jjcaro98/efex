import { Component } from '@angular/core';

@Component({
  selector: 'app-vehiculo',
  standalone: true,
  template: `<h2>Vehículos</h2><p>Aquí se muestra la información de los vehículos.</p>`,
  styles: [`h2 { margin-top: 24px; }`]
})
export class VehiculoComponent {}
