import { Component, Output, EventEmitter, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Cliente, ClienteService } from './cliente.service';

@Component({
  selector: 'app-cliente-form',
  standalone: true,
  imports: [FormsModule, CommonModule],
  template: `
    <form (ngSubmit)="onSubmit()" #clienteForm="ngForm" class="cliente-form">      <div class="form-row">
        <label for="nombre">Nombre:</label>
        <input 
          id="nombre"
          name="nombre" 
          [(ngModel)]="nombre" 
          placeholder="Nombre completo" 
          required 
          [class.invalid]="submitted && !nombre" />
      </div>
      <div class="form-row">
        <label for="apellido">Apellido:</label>
        <input 
          id="apellido"
          name="apellido" 
          [(ngModel)]="Apellido" 
          placeholder="Apellido" 
          required 
          [class.invalid]="submitted && !Apellido" />
      </div>
      <div class="form-row">
        <label for="documento">Documento:</label>
        <input 
          id="documento"
          name="documento" 
          [(ngModel)]="documento" 
          placeholder="Número de documento" 
          required 
          [class.invalid]="submitted && !documento" />
      </div>
      <div class="form-row">
        <label for="telefono">Teléfono:</label>
        <input 
          id="telefono"
          name="telefono" 
          [(ngModel)]="telefono" 
          placeholder="Número de teléfono" 
          required 
          [class.invalid]="submitted && !telefono" />
      </div>
      <div class="form-row">
        <label for="email">Email:</label>
        <input 
          id="email"
          name="email" 
          [(ngModel)]="email" 
          placeholder="Correo electrónico" 
          type="email" />
      </div>
      <div class="form-row">
        <label for="direccion">Dirección:</label>
        <input 
          id="direccion"
          name="direccion" 
          [(ngModel)]="direccion" 
          placeholder="Dirección" />
      </div>
      <div class="form-actions">
        <button type="submit">Guardar</button>
        <button type="button" (click)="onCerrar()" class="btn-cerrar">Cancelar</button>
      </div>
    </form>
  `,
  styles: [`
    .cliente-form {
      padding: 15px;
      max-width: 500px;
      margin: 0 auto;
    }
    
    .form-row {
      margin-bottom: 15px;
      display: flex;
      flex-direction: column;
    }
    
    label {
      margin-bottom: 5px;
      font-weight: 500;
    }
    
    input {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 16px;
    }
    
    input.invalid {
      border-color: #e74c3c;
      animation: shake 0.5s;
    }
    
    .form-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }
    
    button {
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
    }
    
    button[type="submit"] {
      background-color: #3498db;
      color: white;
    }
    
    button[type="submit"]:hover {
      background-color: #2980b9;
    }
    
    .btn-cerrar {
      background-color: #ecf0f1;
      color: #2c3e50;
    }
    
    .btn-cerrar:hover {
      background-color: #bdc3c7;
    }
    
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
      20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
  `]
})
export class ClienteFormComponent implements OnInit {
  @Input() cliente: Cliente | null = null;
  @Output() clienteGuardado = new EventEmitter<Cliente>();
  @Output() cerrar = new EventEmitter<void>();

  id?: number;
  nombre = '';
  Apellido = ''; // Añadido el campo Apellido
  documento = '';
  telefono = '';
  email = '';
  direccion = '';
  submitted = false;

  constructor(private clienteService: ClienteService) {}
  ngOnInit() {
    if (this.cliente) {
      this.id = this.cliente.id;
      this.nombre = this.cliente.nombre;
      this.Apellido = this.cliente.Apellido || '';
      this.documento = this.cliente.documento;
      this.telefono = this.cliente.telefono;
      this.email = this.cliente.email || '';
      this.direccion = this.cliente.direccion || '';
    }
  }
  onSubmit() {
    this.submitted = true;
    
    if (this.nombre && this.Apellido && this.documento && this.telefono) {
      const cliente: Cliente = {
        id: this.id,
        nombre: this.nombre,
        Apellido: this.Apellido,
        documento: this.documento,
        telefono: this.telefono,
        email: this.email || undefined,
        direccion: this.direccion || undefined
      };
      
      this.clienteGuardado.emit(cliente);
      this.resetForm();
    } else {
      setTimeout(() => {
        this.submitted = false;
      }, 3000);
    }
  }
  resetForm() {
    this.id = undefined;
    this.nombre = '';
    this.Apellido = '';
    this.documento = '';
    this.telefono = '';
    this.email = '';
    this.direccion = '';
    this.submitted = false;
  }

  onCerrar() {
    this.cerrar.emit();
  }
}