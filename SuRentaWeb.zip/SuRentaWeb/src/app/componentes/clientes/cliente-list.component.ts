import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cliente } from './cliente.service';

@Component({
  selector: 'app-cliente-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="cliente-list">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Documento</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Dirección</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let cliente of clientes">
            <td>{{ cliente.id }}</td>
            <td>{{ cliente.nombre }}</td>
            <td>{{ cliente.documento }}</td>
            <td>{{ cliente.telefono }}</td>
            <td>{{ cliente.email || 'No disponible' }}</td>
            <td>{{ cliente.direccion || 'No disponible' }}</td>
            <td class="actions">
              <button class="btn-editar" (click)="onEdit(cliente)" title="Editar cliente">
                ✏️
              </button>
              <button class="btn-eliminar" (click)="onDelete(cliente)" title="Eliminar cliente">
                🗑️
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  styleUrls: ['./cliente-list.component.css']
})
export class ClienteListComponent {
  @Input() clientes: Cliente[] = [];
  @Output() editCliente = new EventEmitter<Cliente>();
  @Output() deleteCliente = new EventEmitter<Cliente>();

  onEdit(cliente: Cliente) {
    this.editCliente.emit(cliente);
  }

  onDelete(cliente: Cliente) {
    if (confirm(`¿Está seguro que desea eliminar al cliente ${cliente.nombre}?`)) {
      this.deleteCliente.emit(cliente);
    }
  }
}