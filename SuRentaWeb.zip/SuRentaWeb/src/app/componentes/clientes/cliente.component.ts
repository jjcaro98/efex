import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ClienteService, Cliente } from './cliente.service';
import { ClienteFormComponent } from './cliente-form.component';
import { ClienteListComponent } from './cliente-list.component';

@Component({
  selector: 'app-cliente',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, ClienteFormComponent, ClienteListComponent],
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css']
})
export class ClienteComponent implements OnInit {
  clientes: Cliente[] = [];
  loading = false;
  error = '';
  filtroDocumento = '';
  modalAbierto = false;
  clienteEditando: Cliente | null = null;
  
  constructor(private clienteService: ClienteService) { }

  ngOnInit(): void {
    this.cargarClientes();
  }

  cargarClientes(): void {
    this.loading = true;
    this.error = '';
    
    this.clienteService.getClientes()
      .subscribe({
        next: (data) => {
          this.clientes = data;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error al cargar clientes:', error);
          this.error = 'Error al cargar clientes. Por favor, intente nuevamente.';
          this.loading = false;
        }
      });
  }

  buscarPorDocumento(): void {
    if (!this.filtroDocumento.trim()) {
      this.cargarClientes();
      return;
    }
    
    this.loading = true;
    this.error = '';
    
    this.clienteService.buscarClientePorDocumento(this.filtroDocumento)
      .subscribe({
        next: (data) => {
          this.clientes = data;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error al buscar clientes:', error);
          this.error = 'Error al buscar clientes. Por favor, intente nuevamente.';
          this.loading = false;
        }
      });
  }

  abrirModal(cliente: Cliente | null = null): void {
    this.clienteEditando = cliente;
    this.modalAbierto = true;
  }

  cerrarModal(): void {
    this.modalAbierto = false;
    this.clienteEditando = null;
  }

  guardarCliente(cliente: Cliente): void {
    this.loading = true;
    
    if (cliente.id) {
      // Actualizar cliente existente
      this.clienteService.updateCliente(cliente)
        .subscribe({
          next: () => {
            this.cargarClientes();
            this.cerrarModal();
          },
          error: (error) => {
            console.error('Error al actualizar cliente:', error);
            this.error = 'Error al actualizar cliente. Por favor, intente nuevamente.';
            this.loading = false;
          }
        });
    } else {
      // Crear nuevo cliente
      this.clienteService.createCliente(cliente)
        .subscribe({
          next: () => {
            this.cargarClientes();
            this.cerrarModal();
          },
          error: (error) => {
            console.error('Error al crear cliente:', error);
            this.error = 'Error al crear cliente. Por favor, intente nuevamente.';
            this.loading = false;
          }
        });
    }
  }

  eliminarCliente(cliente: Cliente): void {
    this.loading = true;
    
    this.clienteService.deleteCliente(cliente.id!)
      .subscribe({
        next: () => {
          this.cargarClientes();
        },
        error: (error) => {
          console.error('Error al eliminar cliente:', error);
          this.error = 'Error al eliminar cliente. Por favor, intente nuevamente.';
          this.loading = false;
        }
      });
  }
}