import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface Cliente {
  id?: number;
  idCliente?: number; // Agregar la posibilidad de tener idCliente en lugar de id
  nombre: string;
  Apellido: string;   // Propiedad principal para el apellido (con mayúscula inicial)
  apellido?: string;  // Propiedad alternativa (con minúscula inicial)
  documento: string;
  telefono: string;
  email?: string;
  direccion?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  private apiUrl = 'https://localhost:7159/baselineapi/api/clientes';
  
  constructor(private http: HttpClient) { }  // Obtener todos los clientes
  getClientes(): Observable<Cliente[]> {
    return this.http.get<Cliente[]>(this.apiUrl)
      .pipe(
        catchError(this.handleError),
        // Normalizar respuesta para manejar las dos variantes de apellido
        map((clientes: any[]) => {
          return clientes.map(cliente => {
            // Si viene apellido (minúscula) pero no Apellido (mayúscula), normalizar
            if (cliente.apellido && !cliente.Apellido) {
              cliente.Apellido = cliente.apellido;
            }
            
            // Si viene idCliente pero no id, normalizar
            if (cliente.idCliente && !cliente.id) {
              cliente.id = cliente.idCliente;
            }
            
            return cliente as Cliente;
          });
        })
      );
  }  // Obtener un cliente por ID
  getClienteById(id: number): Observable<Cliente> {
    return this.http.get<Cliente>(`${this.apiUrl}/${id}`)
      .pipe(
        catchError(this.handleError),
        // Normalizar respuesta para manejar las dos variantes de apellido
        map((cliente: any) => {
          // Si viene apellido (minúscula) pero no Apellido (mayúscula), normalizar
          if (cliente.apellido && !cliente.Apellido) {
            cliente.Apellido = cliente.apellido;
          }
          
          // Si viene idCliente pero no id, normalizar
          if (cliente.idCliente && !cliente.id) {
            cliente.id = cliente.idCliente;
          }
          
          return cliente as Cliente;
        })
      );
  }  // Buscar cliente por documento
  buscarClientePorDocumento(documento: string): Observable<Cliente[]> {
    return this.http.get<Cliente[]>(`${this.apiUrl}/buscar?documento=${documento}`)
      .pipe(
        catchError(this.handleError),
        // Normalizar respuesta para manejar las dos variantes de apellido
        map((clientes: any[]) => {
          return clientes.map(cliente => {
            // Si viene apellido (minúscula) pero no Apellido (mayúscula), normalizar
            if (cliente.apellido && !cliente.Apellido) {
              cliente.Apellido = cliente.apellido;
            }
            
            // Si viene idCliente pero no id, normalizar
            if (cliente.idCliente && !cliente.id) {
              cliente.id = cliente.idCliente;
            }
            
            return cliente as Cliente;
          });
        })
      );
  }

  // Crear un nuevo cliente
  createCliente(cliente: Cliente): Observable<Cliente> {
    return this.http.post<Cliente>(this.apiUrl, cliente)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Actualizar un cliente
  updateCliente(cliente: Cliente): Observable<Cliente> {
    return this.http.put<Cliente>(`${this.apiUrl}/${cliente.id}`, cliente)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Eliminar un cliente
  deleteCliente(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Manejo de errores
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Ocurrió un error desconocido';
    
    if (error.error instanceof ErrorEvent) {
      // Error del lado del cliente
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Error del lado del servidor
      if (error.status === 404) {
        errorMessage = 'No se encontraron datos';
      } else if (error.status === 400) {
        errorMessage = 'Solicitud incorrecta. Verifique los datos enviados.';
      } else if (error.status === 500) {
        errorMessage = 'Error interno del servidor. Intente más tarde.';
      } else {
        errorMessage = `Código: ${error.status}, Mensaje: ${error.message}`;
      }
    }
    
    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }
}