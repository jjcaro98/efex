// Método para buscar un vehículo por placa
buscarVehiculoPorPlaca(placa: string): void {
  // Si la placa está vacía o es muy corta, no buscar
  if (!placa || placa.trim().length < 3) {
    this.errorPlacaVehiculo = 'Ingrese una placa válida con al menos 3 caracteres';
    this.vehiculoSeleccionado = null;
    this.reserva.idVehiculo = 0;
    return;
  }
  
  // Limpiar mensajes de error anteriores
  this.errorPlacaVehiculo = '';
  
  // Buscar vehículos disponibles que coincidan con la placa
  this.vehiculoService.getVehiculosApi('Disponible', new Date().toISOString().split('T')[0])
    .subscribe({
      next: (vehiculos) => {
        // Buscar coincidencia exacta por placa
        const vehiculoEncontrado = vehiculos.find(v => 
          v.placa.toLowerCase() === placa.toLowerCase()
        );
        
        // Si encontramos el vehículo, actualizar el modelo
        if (vehiculoEncontrado) {
          this.vehiculoSeleccionado = vehiculoEncontrado;
          this.reserva.idVehiculo = vehiculoEncontrado.id;
          console.log('Vehículo encontrado por placa:', vehiculoEncontrado);
        } else {
          // Si no se encuentra el vehículo, mostrar mensaje de error
          this.errorPlacaVehiculo = 'No se encontró un vehículo disponible con esta placa';
          this.vehiculoSeleccionado = null;
          this.reserva.idVehiculo = 0;
        }
      },
      error: (error) => {
        console.error('Error al buscar vehículos por placa:', error);
        this.errorPlacaVehiculo = 'Error al buscar vehículos. Intente nuevamente';
        this.vehiculoSeleccionado = null;
        this.reserva.idVehiculo = 0;
      }
    });
}
