import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Reserva } from './reserva.service';
import { ClienteService, Cliente } from '../clientes/cliente.service';
import { VehiculoService, Vehiculo } from '../vehiculos/vehiculo.service';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';

@Component({
  selector: 'app-reserva-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reserva-form.component.html',
  styleUrls: ['./reserva-form.component.css']
})
export class ReservaFormComponent implements OnInit {
  @Input() reserva: Reserva = {
    idVehiculo: 0,
    idCliente: 0,
    fechaInicio: '',
    fechaFin: '',
    idEstadoReserva: 0
  };
    @Output() guardarReserva = new EventEmitter<Reserva>();
  @Output() cancelar = new EventEmitter<void>();
  
  // Propiedades para autocomplete de clientes
  clientesEncontrados: Cliente[] = [];
  mostrarSugerencias = false;
  docClienteInput = '';
  clienteBuscado = false;
  buscandoClientes = false;
  clienteSeleccionadoNombre = '';
  documentoOriginal = ''; // Para guardar el documento original sin formato
  private searchTerms = new Subject<string>();
  // Propiedades para selección de vehículos
  placaVehiculoInput = '';
  vehiculoSeleccionado: Vehiculo | null = null;
  errorPlacaVehiculo = '';
  vehiculosDisponibles: Vehiculo[] = [];
  mostrarSugerenciasVehiculo = false;
  buscandoVehiculos = false;
  vehiculoBuscado = false;
  vehiculoSeleccionadoNombre = '';
  private searchVehiculoTerms = new Subject<string>();

  constructor(
    private clienteService: ClienteService,
    private vehiculoService: VehiculoService
  ) { }  ngOnInit(): void {
    // Configurar la búsqueda reactiva para el autocompletado de clientes
    this.searchTerms.pipe(
      debounceTime(200), // Esperar 200ms después de cada pulsación (más rápido)
      distinctUntilChanged() // Solo buscar si el término ha cambiado
    ).subscribe(term => {
      if (term.trim() !== '') {
        this.buscarClientes(term);
      } else {
        this.clientesEncontrados = [];
        this.mostrarSugerencias = false;
      }
    });

    // Si ya tenemos un ID de cliente, intentamos obtener el documento
    if (this.reserva.idCliente > 0) {
      this.clienteService.getClienteById(this.reserva.idCliente)
        .subscribe({
          next: (cliente) => {
            // Guardar el documento original
            this.documentoOriginal = cliente.documento;
            
            // Actualizar el campo de texto con el nombre completo y documento
            this.docClienteInput = `${cliente.documento} - ${cliente.nombre} ${cliente.Apellido || cliente.apellido || ''}`;
            
            this.clienteBuscado = true;
            // Actualizar el nombre mostrado para el cliente seleccionado
            this.clienteSeleccionadoNombre = this.docClienteInput;
            console.log('Cliente cargado por ID:', cliente);
          },
          error: () => {
            this.clienteBuscado = false;
          }
        });
    }
    
    // Si ya tenemos un ID de vehículo, intentamos obtener la placa
    if (this.reserva.idVehiculo > 0) {
      // Obtener todos los vehículos disponibles
      this.vehiculoService.getVehiculosApi('Disponible', new Date().toISOString().split('T')[0])
        .subscribe({
          next: (vehiculos) => {
            const vehiculo = vehiculos.find(v => v.id === this.reserva.idVehiculo);
            if (vehiculo) {
              this.placaVehiculoInput = vehiculo.placa;
              this.vehiculoSeleccionado = vehiculo;
              console.log('Vehículo cargado por ID:', vehiculo);
            }
          },
          error: () => {
            this.vehiculoSeleccionado = null;
            this.errorPlacaVehiculo = '';
          }
        });
    }
  }
  }  // Método para buscar clientes
  buscarClientes(documento: string): void {
    // Si el documento es menor a 2 caracteres, no buscar aún
    if (documento.trim().length < 2) {
      this.clientesEncontrados = [];
      this.mostrarSugerencias = false;
      this.buscandoClientes = false;
      return;
    }
    
    // Mostrar el estado de búsqueda
    this.buscandoClientes = true;
    this.mostrarSugerencias = true;
    
    // Realizar la búsqueda
    this.clienteService.buscarClientePorDocumento(documento)
      .subscribe({
        next: (clientes) => {
          console.log('Clientes encontrados:', clientes);
          
          // Verificar el contenido de los clientes encontrados
          if (clientes.length > 0) {
            console.log('Primer cliente (detalle):', JSON.stringify(clientes[0]));
            console.log('Propiedades del primer cliente:', Object.keys(clientes[0]));
            
            // Verificar si tiene Apellido o apellido
            const primerCliente = clientes[0];
            console.log('- Apellido (mayúscula):', primerCliente.Apellido);
            console.log('- apellido (minúscula):', (primerCliente as any).apellido);
          } else {
            console.log('No se encontraron clientes');
          }
          
          this.clientesEncontrados = clientes;
          
          // Mantener la lista de sugerencias visible incluso con 1 resultado
          this.mostrarSugerencias = true;
          
          // Solo desactivar el estado de carga
          this.buscandoClientes = false;
          
          // Si el cliente ya está seleccionado, no mostrar sugerencias
          if (this.clienteBuscado && this.reserva.idCliente > 0) {
            this.mostrarSugerencias = false;
          }
        },
        error: (error) => {
          console.error('Error al buscar clientes:', error);
          this.clientesEncontrados = [];
          this.buscandoClientes = false;
        },
        complete: () => {
          // Asegurarse de que siempre se quite el estado de carga
          this.buscandoClientes = false;
        }
      });
  }  // Método para recibir input del documento de cliente
  onSearchCliente(documento: string): void {
    // Si ya había un cliente seleccionado, resetear ese estado
    if (this.clienteBuscado) {
      this.clienteBuscado = false;
      this.reserva.idCliente = 0;
      this.documentoOriginal = '';
      this.clienteSeleccionadoNombre = '';
    }
    
    this.docClienteInput = documento;
    
    // Actualizar el estado de la UI inmediatamente
    if (documento.trim() === '') {
      this.mostrarSugerencias = false;
      this.clientesEncontrados = [];
      this.buscandoClientes = false;
    } else if (documento.trim().length >= 2) {
      // Si hay al menos 2 caracteres, mostrar el estado de búsqueda
      this.mostrarSugerencias = true;
      if (!this.buscandoClientes) {
        this.buscandoClientes = true;
      }
    }
    
    // Enviar el término de búsqueda para procesamiento
    this.searchTerms.next(documento);
  }// Método para seleccionar un cliente de las sugerencias  
  seleccionarCliente(cliente: any): void {
    // Verificar si el cliente tiene id o idCliente
    if (!cliente || (!cliente.id && !cliente.idCliente)) {
      console.error('Intento de seleccionar un cliente inválido:', cliente);
      return;
    }
    
    // Normalizar el ID del cliente
    const clienteId = cliente.id || cliente.idCliente;
    
    // Normalizar el cliente en caso de que venga con apellido en minúscula
    if (cliente.apellido && !cliente.Apellido) {
      cliente.Apellido = cliente.apellido;
    }
    
    // Depuración de propiedades
    console.log('Propiedades del cliente seleccionado:');
    console.log('- id:', cliente.id);
    console.log('- idCliente:', cliente.idCliente);
    console.log('- ID usado:', clienteId);
    console.log('- nombre:', cliente.nombre);
    console.log('- documento:', cliente.documento);
    console.log('- Apellido (con mayúscula):', cliente.Apellido);
    console.log('- apellido (con minúscula):', (cliente as any).apellido);    console.log('- Todas las propiedades:', Object.keys(cliente));
    console.log('- Cliente completo:', JSON.stringify(cliente));    
    
    // Actualizar el modelo y la UI - usar el ID normalizado
    this.reserva.idCliente = clienteId;
      
    // Guardar el documento original para enviar al backend
    this.documentoOriginal = cliente.documento;
    
    // Actualizar el campo de texto con el nombre completo y documento
    this.docClienteInput = `${cliente.documento} - ${cliente.nombre} ${cliente.Apellido || cliente.apellido || ''}`;
    
    // Actualizar el nombre mostrado para el cliente seleccionado
    this.clienteSeleccionadoNombre = this.docClienteInput;
    
    // Actualizar estados inmediatamente sin setTimeout para evitar problemas con el modal
    this.mostrarSugerencias = false;
    this.buscandoClientes = false;
    this.clienteBuscado = true;
    
    console.log('Cliente seleccionado:', cliente);
    console.log('Documento original (para backend):', this.documentoOriginal);
  }
  // Método para cambiar cliente
  cambiarCliente(): void {
    this.clienteBuscado = false;
    this.docClienteInput = '';
    this.clienteSeleccionadoNombre = '';
    this.documentoOriginal = '';
    this.reserva.idCliente = 0;
  }
  onSubmit(): void {
    // Verificar que tenemos un cliente seleccionado
    if (this.clienteBuscado && this.reserva.idCliente) {
      // Obtener el cliente seleccionado antes de enviar
      this.clienteService.getClienteById(this.reserva.idCliente)
        .subscribe({
          next: (cliente) => {
            console.log('Cliente recuperado antes de enviar:', cliente);
            // Guardar el documento original en el objeto de reserva si es necesario
            // Ya tenemos el ID del cliente, así que no hace falta hacer nada más
            
            // Enviar la reserva
            this.guardarReserva.emit(this.reserva);
          },
          error: (error) => {
            console.error('Error al recuperar cliente antes de enviar:', error);
            // Enviar la reserva de todos modos
            this.guardarReserva.emit(this.reserva);
          }
        });
    } else {
      // No hay cliente seleccionado, pero enviamos lo que tengamos
      this.guardarReserva.emit(this.reserva);
    }
  }
  onCancelar(): void {
    this.cancelar.emit();
  }
  // Método para buscar vehículos
  buscarVehiculos(placa: string): void {
    // Si la placa es menor a 2 caracteres, no buscar aún
    if (placa.trim().length < 2) {
      this.vehiculosDisponibles = [];
      this.mostrarSugerenciasVehiculo = false;
      this.buscandoVehiculos = false;
      return;
    }
    
    // Mostrar el estado de búsqueda
    this.buscandoVehiculos = true;
    this.mostrarSugerenciasVehiculo = true;
    
    // Obtener vehículos disponibles
    this.vehiculoService.getVehiculosApi('Disponible', new Date().toISOString().split('T')[0])
      .subscribe({
        next: (vehiculos) => {
          console.log('Vehículos disponibles:', vehiculos);
          
          // Filtrar por placa
          this.vehiculosDisponibles = vehiculos.filter(v => 
            v.placa.toLowerCase().includes(placa.toLowerCase())
          );
          
          // Verificar resultados
          if (this.vehiculosDisponibles.length > 0) {
            console.log('Primer vehículo (detalle):', JSON.stringify(this.vehiculosDisponibles[0]));
          } else {
            console.log('No se encontraron vehículos con esta placa');
          }
          
          // Mantener la lista de sugerencias visible incluso con 1 resultado
          this.mostrarSugerenciasVehiculo = true;
          
          // Solo desactivar el estado de carga
          this.buscandoVehiculos = false;
          
          // Si el vehículo ya está seleccionado, no mostrar sugerencias
          if (this.vehiculoBuscado && this.reserva.idVehiculo > 0) {
            this.mostrarSugerenciasVehiculo = false;
          }
        },
        error: (error) => {
          console.error('Error al buscar vehículos:', error);
          this.vehiculosDisponibles = [];
          this.buscandoVehiculos = false;
        },
        complete: () => {
          // Asegurarse de que siempre se quite el estado de carga
          this.buscandoVehiculos = false;
        }
      });
  }

  // Método para recibir input de la placa de vehículo
  onSearchVehiculo(placa: string): void {
    // Si ya había un vehículo seleccionado, resetear ese estado
    if (this.vehiculoBuscado) {
      this.vehiculoBuscado = false;
      this.reserva.idVehiculo = 0;
      this.vehiculoSeleccionadoNombre = '';
    }
    
    this.placaVehiculoInput = placa;
    
    // Actualizar el estado de la UI inmediatamente
    if (placa.trim() === '') {
      this.mostrarSugerenciasVehiculo = false;
      this.vehiculosDisponibles = [];
      this.buscandoVehiculos = false;
    } else if (placa.trim().length >= 2) {
      // Si hay al menos 2 caracteres, mostrar el estado de búsqueda
      this.mostrarSugerenciasVehiculo = true;
      if (!this.buscandoVehiculos) {
        this.buscandoVehiculos = true;
      }
    }
    
    // Enviar el término de búsqueda para procesamiento
    this.searchVehiculoTerms.next(placa);
  }

  // Método para seleccionar un vehículo de las sugerencias
  seleccionarVehiculo(vehiculo: Vehiculo): void {
    if (!vehiculo || !vehiculo.id) {
      console.error('Intento de seleccionar un vehículo inválido:', vehiculo);
      return;
    }
    
    // Depuración de propiedades
    console.log('Propiedades del vehículo seleccionado:');
    console.log('- id:', vehiculo.id);
    console.log('- placa:', vehiculo.placa);
    console.log('- marca:', vehiculo.marca);
    console.log('- modelo:', vehiculo.modelo);
    console.log('- Todas las propiedades:', Object.keys(vehiculo));
    console.log('- Vehículo completo:', JSON.stringify(vehiculo));
    
    // Actualizar el modelo y la UI
    this.reserva.idVehiculo = vehiculo.id;
    
    // Actualizar el campo de texto con la placa, marca y modelo
    this.placaVehiculoInput = `${vehiculo.placa} - ${vehiculo.marca} ${vehiculo.modelo}`;
    
    // Actualizar el nombre mostrado para el vehículo seleccionado
    this.vehiculoSeleccionadoNombre = this.placaVehiculoInput;
    
    // Actualizar estados inmediatamente sin setTimeout para evitar problemas con el modal
    this.mostrarSugerenciasVehiculo = false;
    this.buscandoVehiculos = false;
    this.vehiculoBuscado = true;
    
    console.log('Vehículo seleccionado:', vehiculo);
  }

  // Método para cambiar vehículo
  cambiarVehiculo(): void {
    this.vehiculoBuscado = false;
    this.placaVehiculoInput = '';
    this.vehiculoSeleccionadoNombre = '';
    this.reserva.idVehiculo = 0;
  }
  
  // Método para manejar el evento blur del input
  onInputBlur(): void {
    setTimeout(() => {
      this.mostrarSugerencias = false;
    }, 200);
  }

  // Método para manejar el evento blur del input de vehículo
  onInputVehiculoBlur(): void {
    setTimeout(() => {
      this.mostrarSugerenciasVehiculo = false;
    }, 200);
  }

  // Método para buscar un vehículo por placa
buscarVehiculoPorPlaca(placa: string): void {
  // Si la placa está vacía o es muy corta, no buscar
  if (!placa || placa.trim().length < 3) {
    this.errorPlacaVehiculo = 'Ingrese una placa válida con al menos 3 caracteres';
    this.vehiculoSeleccionado = null;
    this.reserva.idVehiculo = 0;
    return;
  }
  
  // Limpiar mensajes de error anteriores
  this.errorPlacaVehiculo = '';
  
  // Buscar vehículos disponibles que coincidan con la placa
  this.vehiculoService.getVehiculosApi('Disponible', new Date().toISOString().split('T')[0])
    .subscribe({
      next: (vehiculos) => {
        // Buscar coincidencia exacta por placa
        const vehiculoEncontrado = vehiculos.find(v => 
          v.placa.toLowerCase() === placa.toLowerCase()
        );
        
        // Si encontramos el vehículo, actualizar el modelo
        if (vehiculoEncontrado) {
          this.vehiculoSeleccionado = vehiculoEncontrado;
          this.reserva.idVehiculo = vehiculoEncontrado.id;
          console.log('Vehículo encontrado por placa:', vehiculoEncontrado);
        } else {
          // Si no se encuentra el vehículo, mostrar mensaje de error
          this.errorPlacaVehiculo = 'No se encontró un vehículo disponible con esta placa';
          this.vehiculoSeleccionado = null;
          this.reserva.idVehiculo = 0;
        }
      },
      error: (error) => {
        console.error('Error al buscar vehículos por placa:', error);
        this.errorPlacaVehiculo = 'Error al buscar vehículos. Intente nuevamente';
        this.vehiculoSeleccionado = null;
        this.reserva.idVehiculo = 0;
      }
    });
}
}