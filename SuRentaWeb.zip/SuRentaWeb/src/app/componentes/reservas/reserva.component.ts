import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ReservaService, Reserva } from './reserva.service';
import { ReservaFormComponent } from './reserva-form.component';

@Component({
  selector: 'app-reserva',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, ReservaFormComponent],
  templateUrl: './reserva.component.html',
  styleUrls: ['./reserva.component.css']
})
export class ReservaComponent implements OnInit {
  reservas: Reserva[] = [];
  nuevaReserva: Reserva = {
    idVehiculo: 0,
    idCliente: 0,
    fechaInicio: '',
    fechaFin: '',
    idEstadoReserva: 0
  };
  
  loading = false;
  error = '';
  success = '';
  
  // Propiedades para filtros
  filtroReserva = '';
  fechaFiltro = '';
  modalNuevaReserva = false;

  constructor(private reservaService: ReservaService) { }

  ngOnInit(): void {
    this.cargarReservas();
  }

  cargarReservas(): void {
    this.loading = true;
    this.error = '';
    
    this.reservaService.getReservas()
      .subscribe({
        next: (data) => {
          this.reservas = data;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error al cargar reservas:', error);
          this.error = 'Error al cargar reservas. Por favor, intente nuevamente.';
          this.loading = false;
        }
      });
  }

  // Método para formatear la fecha
  formatearFecha(event: Event) {
    const inputValue = (event.target as HTMLInputElement).value;
    this.fechaFiltro = inputValue;
  }
  
  // Método para limpiar la fecha
  limpiarFecha() {
    this.fechaFiltro = '';
  }
  
  // Método para consultar reservas con filtros
  consultarReservas() {
    this.loading = true;
    this.error = '';
    
    this.reservaService.getReservas()
      .subscribe({
        next: (data) => {
          // Filtrar las reservas localmente (esto puede cambiarse por una llamada a la API con filtros)
          let filteredReservas = [...data];
          
          if (this.filtroReserva && this.filtroReserva.trim()) {
            const filtro = this.filtroReserva.trim().toLowerCase();
            filteredReservas = filteredReservas.filter(r => 
              r.id?.toString().includes(filtro) || 
              r.clienteNombre?.toLowerCase().includes(filtro) ||
              r.clienteDocumento?.toLowerCase().includes(filtro)
            );
          }
          
          if (this.fechaFiltro && this.fechaFiltro.trim()) {
            filteredReservas = filteredReservas.filter(r => 
              r.fechaInicio.includes(this.fechaFiltro) || r.fechaFin.includes(this.fechaFiltro)
            );
          }
          
          this.reservas = filteredReservas;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error al consultar reservas:', error);
          this.error = 'Error al consultar reservas. Por favor, intente nuevamente.';
          this.loading = false;
        }
      });
  }
  
  // Métodos para el modal
  abrirModalNuevaReserva() {
    this.limpiarFormulario();
    this.modalNuevaReserva = true;
  }
  
  cerrarModalNuevaReserva() {
    this.modalNuevaReserva = false;
  }

  // Método que recibe el evento del formulario
  guardarReserva(reserva: Reserva): void {
    this.loading = true;
    this.error = '';
    this.success = '';
    
    this.reservaService.createReserva(reserva)
      .subscribe({
        next: (response) => {
          this.success = 'Reserva creada exitosamente';
          this.cargarReservas();
          this.cerrarModalNuevaReserva();
          this.loading = false;
        },
        error: (error) => {
          console.error('Error al crear reserva:', error);
          this.error = 'Error al crear la reserva. Por favor, revise los datos e intente nuevamente.';
          this.loading = false;
        }
      });
  }

  limpiarFormulario(): void {
    this.nuevaReserva = {
      idVehiculo: 0,
      idCliente: 0,
      fechaInicio: '',
      fechaFin: '',
      idEstadoReserva: 0
    };
  }
}
