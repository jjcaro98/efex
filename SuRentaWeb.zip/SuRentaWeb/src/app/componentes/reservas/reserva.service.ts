import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Reserva {
  id?: number;
  idVehiculo: number;
  idCliente: number;
  fechaInicio: string;
  fechaFin: string;
  idEstadoReserva: number;
  // Propiedades extendidas para mostrar información descriptiva
  vehiculoPlaca?: string;
  vehiculoMarca?: string;
  vehiculoModelo?: string;
  clienteNombre?: string;
  clienteDocumento?: string;
  estadoReservaDescripcion?: string;
}

export interface EstadoReserva {
  idEstadoReserva: number;
  descripcion: string;
}

@Injectable({
  providedIn: 'root'
})
export class ReservaService {
  private apiUrl = 'https://localhost:7159/baselineapi/api/reservas';

  constructor(private http: HttpClient) {}

  // Obtener todas las reservas
  getReservas(): Observable<Reserva[]> {
    return this.http.get<Reserva[]>(this.apiUrl).pipe(
      catchError(this.handleError)
    );
  }

  // Crear una nueva reserva
  createReserva(reserva: Reserva): Observable<Reserva> {
    return this.http.post<Reserva>(this.apiUrl, reserva).pipe(
      catchError(this.handleError)
    );
  }

  // Actualizar una reserva existente
  updateReserva(reserva: Reserva): Observable<Reserva> {
    return this.http.put<Reserva>(`${this.apiUrl}/${reserva.id}`, reserva).pipe(
      catchError(this.handleError)
    );
  }

  // Eliminar una reserva
  deleteReserva(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  // Manejador de errores
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Ocurrió un error desconocido';
    
    if (error.error instanceof ErrorEvent) {
      // Error del lado del cliente
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Error del lado del servidor
      if (error.status === 404) {
        errorMessage = 'No se encontraron datos';
      } else if (error.status === 400) {
        errorMessage = 'Solicitud incorrecta. Verifique los datos enviados.';
      } else if (error.status === 500) {
        errorMessage = 'Error interno del servidor. Intente más tarde.';
      } else {
        errorMessage = `Código: ${error.status}, Mensaje: ${error.message}`;
      }
    }
    
    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }
}
