import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NgIf } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [NgIf, RouterModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  @Input() isOpen = true;
  @Output() isOpenChange = new EventEmitter<boolean>();

  vehiculosSubmenuOpen = false;

  toggleSidebar() {
    this.isOpen = !this.isOpen;
    this.isOpenChange.emit(this.isOpen);
  }

  toggleVehiculosSubmenu() {
    this.vehiculosSubmenuOpen = !this.vehiculosSubmenuOpen;
  }

  abrirModalAgregarPlaca() {
    // Aquí se debe implementar la lógica para mostrar el modal de agregar placa
    alert('Abrir modal para agregar placa (implementación pendiente)');
  }
}
