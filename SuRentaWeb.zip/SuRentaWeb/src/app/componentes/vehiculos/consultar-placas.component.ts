import { Component } from '@angular/core';
import { NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehiculoService, Vehiculo } from './vehiculo.service';

@Component({
  selector: 'app-consultar-placas',
  standalone: true,
  imports: [NgIf, FormsModule],
  template: `
    <h2>Consultar Placas</h2>
    <form (ngSubmit)="consultar()" class="vehiculo-filtros">
      <label>
        Estado descripción:
        <input [(ngModel)]="estadoDescripcion" name="estadoDescripcion" placeholder="Estado" />
      </label>
      <label>
        Fecha:
        <input [(ngModel)]="fecha" name="fecha" placeholder="Fecha" />
      </label>
      <button type="submit" class="btn-consultar">Consultar</button>
      <button type="button" class="btn-cerrar" (click)="cerrar()">Cerrar</button>
    </form>
    <table *ngIf="vehiculos.length > 0">
      <thead>
        <tr>
          <th>ID</th>
          <th>Placa</th>
          <th>Marca</th>
          <th>Modelo</th>
          <th>Año</th>
          <th>Tipo Vehículo</th>
          <th>Estado Vehículo</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let v of vehiculos">
          <td>{{ v.id }}</td>
          <td>{{ v.placa }}</td>
          <td>{{ v.marca }}</td>
          <td>{{ v.modelo }}</td>
          <td>{{ v.anio }}</td>
          <td>{{ v.tipoVehiculoDescripcion }}</td>
          <td>{{ v.estadoVehiculoDescripcion }}</td>
        </tr>
      </tbody>
    </table>
    <p *ngIf="vehiculos.length === 0 && consultado">No se encontraron vehículos.</p>
    <div *ngIf="apiError" style="color:red;">Error al consultar la API</div>
    <div *ngIf="apiLoading">Cargando datos...</div>
  `
})
export class ConsultarPlacasComponent {
  estadoDescripcion = '';
  fecha = '';
  vehiculos: Vehiculo[] = [];
  apiLoading = false;
  apiError = false;
  consultado = false;

  constructor(private vehiculoService: VehiculoService) {}

  consultar() {
    this.apiLoading = true;
    this.apiError = false;
    this.consultado = false;
    this.vehiculoService.getVehiculosApi(this.estadoDescripcion, this.fecha).subscribe({
      next: (data) => {
        this.vehiculos = data;
        this.apiLoading = false;
        this.consultado = true;
      },
      error: () => {
        this.apiError = true;
        this.apiLoading = false;
        this.consultado = true;
      }
    });
  }

  cerrar() {
    this.estadoDescripcion = '';
    this.fecha = '';
    this.vehiculos = [];
    this.apiError = false;
    this.apiLoading = false;
    this.consultado = false;
  }
}
