import { Component, Output, EventEmitter, Input, OnInit, ViewChildren, ElementRef, QueryList } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { VehiculoService } from './vehiculo.service';

@Component({
  selector: 'app-vehiculo-form',
  standalone: true,
  imports: [FormsModule, CommonModule],
  template: `
    <form (ngSubmit)="onSubmit()" #vehiculoForm="ngForm" class="vehiculo-form">
      <div class="form-row">
        <input 
          name="placa" 
          [(ngModel)]="placa" 
          placeholder="Placa" 
          required 
          #placaInput
          [class.invalid]="submitted && !placa" />
        <input 
          name="marca" 
          [(ngModel)]="marca" 
          placeholder="Marca" 
          required 
          #marcaInput
          [class.invalid]="submitted && !marca" />
      </div>
      <div class="form-row">
        <input 
          name="modelo" 
          [(ngModel)]="modelo" 
          placeholder="Modelo" 
          required 
          #modeloInput
          [class.invalid]="submitted && !modelo" />
        <input 
          name="anio" 
          [(ngModel)]="anio" 
          placeholder="Año" 
          type="number" 
          required 
          #anioInput
          [class.invalid]="submitted && anio === null" />
      </div>      
      <div class="form-row">
        <select 
          name="tipoVehiculoDescripcion" 
          [(ngModel)]="tipoVehiculoDescripcion" 
          required 
          [disabled]="!tiposLoaded"
          #tipoInput
          [class.invalid]="submitted && !tipoVehiculoDescripcion">
          <option value="" disabled>Seleccione tipo</option>
          <option *ngFor="let tipo of tipos" [value]="tipo.descripcion">{{ tipo.descripcion }}</option>
        </select>        <select 
          name="estadoVehiculoDescripcion" 
          [(ngModel)]="estadoVehiculoDescripcion" 
          required 
          [disabled]="!estadosLoaded"
          #estadoInput
          [class.invalid]="submitted && !estadoVehiculoDescripcion">
          <option value="" disabled>Seleccione estado</option>
          <option *ngFor="let estado of estados" [value]="estado.descripcion">{{ estado.descripcion }}</option>
        </select>
      </div>      <div *ngIf="estadosLoaded && estados.length === 0" style="color: red; font-size: 0.9em; margin-bottom: 8px;">
        No se encuentra el estado "Disponible". Contacte al administrador.
      </div>
      <div *ngIf="tiposLoaded && tipos.length === 0" style="color: red; font-size: 0.9em; margin-bottom: 8px;">
        No hay tipos disponibles.
      </div>
      <div class="form-actions">
        <button type="submit">Guardar</button>
        <button type="button" (click)="onCerrar()" class="btn-cerrar">Cerrar</button>
      </div>
    </form>
  `,
  styleUrls: ['./vehiculo-form.component.css']
})
export class VehiculoFormComponent implements OnInit {
  @Input() placa = '';
  @Input() marca = '';
  @Input() modelo = '';
  @Input() anio: number | null = null;
  @Input() tipoVehiculoDescripcion = '';
  @Input() estadoVehiculoDescripcion = '';
  @Output() vehiculoCreado = new EventEmitter<{ 
    placa: string; 
    marca: string; 
    modelo: string; 
    anio: number; 
    tipoVehiculoDescripcion: string; 
    idTipoVehiculo: number;
    idEstadoVehiculo: number;
    estadoVehiculoDescripcion: string;
  }>();
  @Input() cerrarForm?: () => void;
  @Output() cerrar = new EventEmitter<void>();

  // Referencias a los inputs para validación visual
  @ViewChildren('placaInput, marcaInput, modeloInput, anioInput, tipoInput, estadoInput') 
  formInputs!: QueryList<ElementRef>;

  estados: { idEstadoVehiculo: number; descripcion: string }[] = [];
  tipos: { idTipoVehiculo: number; descripcion: string }[] = [];
  estadosLoaded = false;
  tiposLoaded = false;
  submitted = false;

  constructor(private vehiculoService: VehiculoService) {}
  ngOnInit() {
    this.vehiculoService.getEstadosVehiculo().subscribe(estados => {
      // Filter to only show "Disponible" state
      this.estados = estados.filter(estado => estado.descripcion === "Disponible");
      this.estadosLoaded = true;
      
      // If "Disponible" state is found, auto-select it
      if (this.estados.length === 1) {
        this.estadoVehiculoDescripcion = this.estados[0].descripcion;
      }
    });
    
    this.vehiculoService.getTiposVehiculo().subscribe(tipos => {
      this.tipos = tipos;
      this.tiposLoaded = true;
    });
  }

  onSubmit() {
    this.submitted = true;
    
    if (
      this.placa &&
      this.marca &&
      this.modelo &&
      this.anio !== null &&
      this.tipoVehiculoDescripcion &&
      this.estadoVehiculoDescripcion
    ) {
      const estado = this.estados.find(e => e.descripcion === this.estadoVehiculoDescripcion);
      const tipo = this.tipos.find(t => t.descripcion === this.tipoVehiculoDescripcion);
      
      this.vehiculoCreado.emit({
        placa: this.placa,
        marca: this.marca,
        modelo: this.modelo,
        anio: this.anio,
        tipoVehiculoDescripcion: this.tipoVehiculoDescripcion,
        idTipoVehiculo: tipo ? tipo.idTipoVehiculo : 0,
        idEstadoVehiculo: estado ? estado.idEstadoVehiculo : 0,
        estadoVehiculoDescripcion: this.estadoVehiculoDescripcion
      });
      
      this.placa = '';
      this.marca = '';
      this.modelo = '';
      this.anio = null;
      this.tipoVehiculoDescripcion = '';
      this.estadoVehiculoDescripcion = '';
      this.submitted = false;
    } else {
      // Aplicar efecto de shake y remover después de unos segundos
      setTimeout(() => {
        this.submitted = false;
      }, 3000);
    }
  }

  onCerrar() {
    if (this.cerrarForm) {
      this.cerrarForm();
    } else {
      this.cerrar.emit();
    }
  }
}
