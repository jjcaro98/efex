import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NgIf, NgFor, DatePipe } from '@angular/common';
import { VehiculoService, Vehiculo } from './vehiculo.service';
import { ActivatedRoute } from '@angular/router';

@Component({  selector: 'app-vehiculo-list',
  standalone: true,
  imports: [NgIf, NgFor, DatePipe],template: `
    <div style="display: flex; align-items: center; justify-content: space-between;">
      <h2 *ngIf="showAll">Administrar Placas</h2>  
    </div>
    <table *ngIf="vehiculos.length > 0">      <thead>
        <tr>
          <th>Placa</th>
          <th>Marca</th>
          <th>Modelo</th>
          <th>Año</th>
          <th>Tipo Vehículo</th>
          <th class="sortable" (click)="sortByEstado()">
            Estado Vehículo
            <span *ngIf="sortedByEstado" class="sort-icon">
              {{ sortDirection === 'asc' ? '▲' : '▼' }}
            </span>
          </th>
          <th>Fecha Inicio</th>
          <th>Fecha Fin</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let v of vehiculos">
          <td>{{ v.placa }}</td>
          <td>{{ v.marca }}</td>
          <td>{{ v.modelo }}</td>
          <td>{{ v.anio }}</td>          <td>{{ v.tipoVehiculoDescripcion }}</td>
          <td>{{ v.estadoVehiculoDescripcion }}</td>
          <td>{{ v.fechaInicio ? (v.fechaInicio | date:'dd/MM/yyyy') : '-' }}</td>
          <td>{{ v.fechaFin ? (v.fechaFin | date:'dd/MM/yyyy') : '-' }}</td>
          <td class="actions-cell">
            <button class="btn-action btn-edit" (click)="onEdit(v)" title="Editar">
              <span>✎</span>
            </button>
            <button class="btn-action btn-delete" (click)="onDelete(v)" title="Eliminar">
              <span>✖</span>
            </button>
          </td>
        </tr>
      </tbody>    </table>
    <div *ngIf="vehiculos.length === 0" class="no-data">
      <!-- Contenedor vacío, no mostramos mensaje -->
    </div>
  `,
  styles: [`
    table { 
      width: 100%; 
      border-collapse: collapse; 
      margin-top: 16px; 
    } 
    th, td { 
      border: 1px solid #ccc; 
      padding: 8px; 
    }
    th.sortable {
      cursor: pointer;
      user-select: none;
      position: relative;
      background-color: #f8f9fa;
    }
    th.sortable:hover {
      background-color: #e2e6ea;
    }
    .sort-icon {
      margin-left: 5px;
      font-size: 12px;
    }
  `]
})
export class VehiculoListComponent {
  @Input() vehiculos: Vehiculo[] = [];
  @Output() editVehiculo = new EventEmitter<Vehiculo>();
  @Output() deleteVehiculo = new EventEmitter<Vehiculo>();
  showAll = false;
  sortedByEstado = false;
  sortDirection = 'asc';

  constructor(route: ActivatedRoute, private vehiculoService: VehiculoService) {
    this.showAll = !!route.snapshot.data['showAll'];
    if (this.showAll) {
      this.vehiculos = this.vehiculoService.getVehiculos();
    }
  }
  
  onEdit(vehiculo: Vehiculo) {
    this.editVehiculo.emit(vehiculo);
  }
  
  onDelete(vehiculo: Vehiculo) {
    if (confirm(`¿Está seguro que desea eliminar el vehículo con placa ${vehiculo.placa}?`)) {
      this.deleteVehiculo.emit(vehiculo);
    }
  }

  sortByEstado() {
    this.sortDirection = this.sortedByEstado && this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.sortedByEstado = true;
    
    this.vehiculos = [...this.vehiculos].sort((a, b) => {
      if (this.sortDirection === 'asc') {
        return a.estadoVehiculoDescripcion.localeCompare(b.estadoVehiculoDescripcion);
      } else {
        return b.estadoVehiculoDescripcion.localeCompare(a.estadoVehiculoDescripcion);
      }
    });
  }
}
