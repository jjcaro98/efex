import { Component } from '@angular/core';
import { NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehiculoService, Vehiculo } from './vehiculo.service';
import { VehiculoFormComponent } from './vehiculo-form.component';
import { VehiculoListComponent } from './vehiculo-list.component';
import { timeout } from 'rxjs';

@Component({
  selector: 'app-vehiculo',
  standalone: true,
  imports: [NgIf, FormsModule, VehiculoFormComponent, VehiculoListComponent],
  templateUrl: './vehiculo.component.html',
  styleUrls: ['./vehiculo.component.css']
})
export class VehiculoComponent {  vehiculos: Vehiculo[] = [];
  vehiculosApi: Vehiculo[] = [];
  apiLoading = false;
  apiError = false;  noVehiclesFound = false;
  estadoDescripcion = '';
  fecha = '';
  modalAgregarPlaca = false;
  modalEditarPlaca = false;
  vehiculoEditando: Vehiculo | null = null;
  constructor(private vehiculoService: VehiculoService) {
    // Ya no inicializamos con la fecha actual para permitir búsquedas sin fecha
    this.fecha = '';
  }

  formatearFecha(event: Event) {
    const inputValue = (event.target as HTMLInputElement).value;
    this.fecha = inputValue;
  }
  
  limpiarFecha() {
    this.fecha = '';
  }  consultarApi() {
    this.apiLoading = true;
    this.apiError = false;
    this.noVehiclesFound = false;
    
    // Asegurarse de que la fecha tenga el formato correcto (YYYY-MM-DD) si no está vacía
    let fechaConsulta = this.fecha.trim();
    
    if (fechaConsulta && !fechaConsulta.match(/^\d{4}-\d{2}-\d{2}$/)) {
      // Si no tiene el formato correcto y no está vacía, lo convertimos
      try {
        const fechaObj = new Date(fechaConsulta);
        fechaConsulta = fechaObj.toISOString().split('T')[0];
      } catch (e) {
        console.error('Formato de fecha incorrecto:', fechaConsulta);
        fechaConsulta = '';
      }
    }
    
    this.vehiculoService.getVehiculosApi(this.estadoDescripcion, fechaConsulta)
      .pipe(timeout(20000))
      .subscribe({
        next: (data) => {
          this.vehiculosApi = data;
          this.apiLoading = false;
          this.noVehiclesFound = data.length === 0;
        },
        error: (err) => {
          console.error('Error al consultar la API:', err);
          // Si el error es 404, considerarlo como "no se encontraron vehículos" en lugar de un error
          if (err.status === 404) {
            this.noVehiclesFound = true;
            this.apiError = false;
          } else {
            this.apiError = true;
          }
          this.apiLoading = false;
        }
      });
  }

  agregarVehiculo(vehiculo: Omit<Vehiculo, 'id'>) {
    this.vehiculoService.addVehiculo(vehiculo);
    this.vehiculos = this.vehiculoService.getVehiculos();
  }
  abrirModalAgregarPlaca() {
    this.modalAgregarPlaca = true;
  }

  cerrarModalAgregarPlaca() {
    this.modalAgregarPlaca = false;
  }  onVehiculoCreadoModal(vehiculo: any) {
    this.vehiculoService.addVehiculoApi({
      placa: vehiculo.placa,
      marca: vehiculo.marca,
      modelo: vehiculo.modelo,
      anio: vehiculo.anio,
      idTipoVehiculo: vehiculo.idTipoVehiculo,
      idEstadoVehiculo: vehiculo.idEstadoVehiculo
    }).subscribe({
      next: () => {
        this.noVehiclesFound = false; // Reset this flag
        this.consultarApi();
        this.cerrarModalAgregarPlaca();
      },
      error: () => {
        this.cerrarModalAgregarPlaca();
      }
    });
  }
  
  editarVehiculo(vehiculo: Vehiculo) {
    this.vehiculoEditando = { ...vehiculo };
    this.abrirModalEditarPlaca();
  }
  
  eliminarVehiculo(vehiculo: Vehiculo) {
    // Si es un vehículo local
    const eliminado = this.vehiculoService.deleteVehiculo(vehiculo.id);
    
    // Si se elimina de la lista local, también actualizamos la lista de la API
    if (eliminado && this.vehiculosApi.length > 0) {
      this.vehiculosApi = this.vehiculosApi.filter(v => v.id !== vehiculo.id);
    }
  }
  
  abrirModalEditarPlaca() {
    this.modalEditarPlaca = true;
  }
  
  cerrarModalEditarPlaca() {
    this.modalEditarPlaca = false;
    this.vehiculoEditando = null;
  }
  
  guardarEdicionVehiculo(vehiculo: Omit<Vehiculo, 'id'>) {
    if (this.vehiculoEditando) {
      const vehiculoActualizado = {
        ...vehiculo,
        id: this.vehiculoEditando.id
      };
      
      this.vehiculoService.updateVehiculo(vehiculoActualizado);
      
      // Actualizar en la lista de la API si existe
      const index = this.vehiculosApi.findIndex(v => v.id === vehiculoActualizado.id);
      if (index !== -1) {
        this.vehiculosApi[index] = vehiculoActualizado;
      }
      
      this.cerrarModalEditarPlaca();
    }
  }
}
