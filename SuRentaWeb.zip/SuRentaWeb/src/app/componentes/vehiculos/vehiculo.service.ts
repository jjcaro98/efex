import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

export interface Vehiculo {
  id: number;
  placa: string;
  marca: string;
  modelo: string;
  anio: number;
  tipoVehiculoDescripcion: string;
  estadoVehiculoDescripcion: string;
  fechaInicio?: string;
  fechaFin?: string;
}

@Injectable({ providedIn: 'root' })
export class VehiculoService {
  private vehiculos: Vehiculo[] = [];
  private idCounter = 1;
  private apiUrl = 'https://localhost:7159/baselineapi/api/vehiculos/filtrar';
  private apiPostUrl = 'https://localhost:7159/baselineapi/api/vehiculos';

  constructor(private http: HttpClient) {}
  getVehiculos(): Vehiculo[] {
    return this.vehiculos;
  }

  addVehiculo(vehiculo: Omit<Vehiculo, 'id'>) {
    this.vehiculos.push({ ...vehiculo, id: this.idCounter++ });
  }
  
  updateVehiculo(vehiculo: Vehiculo) {
    const index = this.vehiculos.findIndex(v => v.id === vehiculo.id);
    if (index !== -1) {
      this.vehiculos[index] = { ...vehiculo };
      return true;
    }
    return false;
  }
  
  deleteVehiculo(id: number) {
    const index = this.vehiculos.findIndex(v => v.id === id);
    if (index !== -1) {
      this.vehiculos.splice(index, 1);
      return true;
    }
    return false;
  }  getVehiculosApi(estadoDescripcion: string, fecha: string): Observable<Vehiculo[]> {
    // Construir parámetros para la API manualmente para más control
    let url = this.apiUrl;
    const params: string[] = [];
    
    if (estadoDescripcion && estadoDescripcion.trim()) {
      params.push(`estadoDescripcion=${encodeURIComponent(estadoDescripcion.trim())}`);
    }
    
    if (fecha && fecha.trim()) {
      params.push(`fecha=${encodeURIComponent(fecha.trim())}`);
    }
    
    if (params.length > 0) {
      url = `${url}?${params.join('&')}`;
    }    
    console.log('URL de consulta:', url);
    
    return this.http.get<Vehiculo[]>(url).pipe(
      catchError(this.handleError)
    );
  }
    private handleError(error: HttpErrorResponse) {
    console.error('Error en la API:', error);
    
    // No transformamos el error, simplemente lo propagamos para que el componente
    // pueda acceder a las propiedades como error.status
    return throwError(() => error);
  }

  addVehiculoApi(data: {
    placa: string;
    marca: string;
    modelo: string;
    anio: number;
    idTipoVehiculo: number;
    idEstadoVehiculo: number;
  }): Observable<any> {
    const body = {
      idVehiculo: 0,
      ...data
    };
    return this.http.post(this.apiPostUrl, body);
  }
  getEstadosVehiculo() {
    return this.http.get<{ idEstadoVehiculo: number; descripcion: string }[]>(
      'https://localhost:7159/baselineapi/api/vehiculos/estados'
    );
  }

  getTiposVehiculo() {
    return this.http.get<{ idTipoVehiculo: number; descripcion: string }[]>(
      'https://localhost:7159/baselineapi/api/vehiculos/tipos'
    );
  }
}
