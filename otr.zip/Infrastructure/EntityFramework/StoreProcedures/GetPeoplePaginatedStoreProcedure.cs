﻿using System.Data;
using Renting.BaseLine.Infrastructure.EntityFramework.Helpers;

namespace Renting.BaseLine.Infrastructure.EntityFramework.StoreProcedures
{
    public class GetPeoplePaginatedStoreProcedure
    {
        [SqlParameter("PageIndex", Direction = ParameterDirection.Input)]
        public int PageIndex { get; set; }

        [SqlParameter("PageSize", Direction = ParameterDirection.Input)]
        public int PageSize { get; set; }

        [SqlParameter("TotalCount", Direction = ParameterDirection.Output)]
        public int TotalCount { get; set; }
    }
}
