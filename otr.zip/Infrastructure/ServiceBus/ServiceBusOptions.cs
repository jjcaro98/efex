﻿using Renting.BaseLine.Application.Services.Notifications;

namespace Renting.BaseLine.Infrastructure.ServiceBus
{
    public class ServiceBusOptions
    {
        public const string Key = "ServiceBus";

        public string Endpoint { get; set; } = string.Empty;

        public List<string> Queues { get; set; } = new List<string>();

        public int MaxDeliveryCount { get; set; } = 10;

        public int MaxRetryCount { get; set; } = 5;

        public int RetrySeconds { get; set; } = 300;

        public ServiceBusNotificationsOptions Notifications { get; set; } = new();

        public class ServiceBusNotificationsOptions
        {
            public bool IsEnabled { get; set; }

            public string Title { get; set; } = string.Empty;

            public string Body { get; set; } = string.Empty;

            public EmailUserName Sender { get; set; } = new("", "");

            public List<EmailUserName> Recipients { get; set; } = new();
        }
    }
}
