﻿using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace Renting.BaseLine.Infrastructure.Services.Authorization
{
    public class AuthorizationService : BaseService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public AuthorizationService(IHttpClientFactory httpClientFactory, IConfiguration configuration, ILogger logger) : base(configuration, logger)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<string> GetTokenAsync()
        {
            var client = _httpClientFactory.CreateClient("Authorization");

            client.DefaultRequestHeaders.Add(_configuration["Services:Authorization:GetToken:HeaderKey"]!,
                Enumerable.Repeat(_configuration["Services:Authorization:GetToken:HeaderValue"], 1));

            var tokenResponse = await ExecuteAndRetryAsync(async () =>
            {
                return await client.GetFromJsonAsync<TokenResponse>(_configuration["Services:Authorization:GetToken:RequestUri"]) ?? throw new TokenEmptyException();
            });

            return tokenResponse.Token;
        }
    }
}
