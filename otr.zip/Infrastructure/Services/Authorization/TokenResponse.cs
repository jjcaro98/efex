﻿using System.Text.Json.Serialization;

namespace Renting.BaseLine.Infrastructure.Services.Authorization
{
    public class TokenResponse
    {
        [JsonPropertyName("token")]
        public string Token { get; set; } = string.Empty;

        [JsonPropertyName("refresh")]
        public string Refresh { get; set; } = string.Empty;
    }
}
