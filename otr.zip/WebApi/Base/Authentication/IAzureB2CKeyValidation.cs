﻿using Microsoft.IdentityModel.Tokens;

namespace Renting.BaseLine.WebApi.Base.Authentication
{
    public interface IAzureB2CKeyValidation
    {
        Task<IEnumerable<SecurityKey>> GetKeysAsync();

        void InvalidateKeys();
    }
}
