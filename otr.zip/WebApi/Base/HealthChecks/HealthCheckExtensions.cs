﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Renting.BaseLine.WebApi.Base.HealthChecks
{
    public static class HealthCheckExtensions
    {
        public static IServiceCollection AddRentingHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHealthChecks()
                .AddCheck("self", () => HealthCheckResult.Healthy(), tags: new List<string> { "ms" })
                .AddCheck("db-check", new DatabaseHealthCheck("ConnectionStrings:Base", configuration), tags: new List<string> { "db" });

            return services;
        }
    }
}
