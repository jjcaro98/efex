using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Renting.BaseLine.Application.Clientes.GetClientes;
using Renting.BaseLine.Application.Clientes.GetClienteByDocumento;
using Renting.BaseLine.Application.Clientes.GetClientesByDocumento;
using Renting.BaseLine.Application.Exceptions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Renting.BaseLine.WebApi.Controllers
{
    [Route("api/clientes")]
    [ApiController]
    public class ClientesController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ClientesController> _logger;

        public ClientesController(IMediator mediator, ILogger<ClientesController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<ClienteDto>>> Get()
        {
            try
            {
                var clientes = await _mediator.Send(new GetClientesQuery());
                return Ok(clientes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en GET /api/clientes");
                return StatusCode(500);
            }
        }

        [HttpGet("buscar")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<ClienteDto>>> GetByDocumento([FromQuery] string documento)
        {
            try
            {
                if (string.IsNullOrEmpty(documento))
                {
                    return BadRequest(new { message = "El parámetro documento es obligatorio" });
                }
                
                var clientes = await _mediator.Send(new GetClientesByDocumentoQuery(documento));
                return Ok(clientes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en GET /api/clientes/buscar?documento={Documento}", documento);
                return StatusCode(500);
            }
        }
    }
}
