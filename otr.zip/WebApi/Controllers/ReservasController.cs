using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Renting.BaseLine.Application.Reservas.CreateReserva;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.WebApi.Controllers
{
    [Route("api/reservas")]
    [ApiController]
    public class ReservasController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ReservasController> _logger;

        public ReservasController(IMediator mediator, ILogger<ReservasController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Post([FromBody] CreateReservaCommand command)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                var reservaDto = await _mediator.Send(command);
                return CreatedAtAction(nameof(Post), new { id = reservaDto.IdReserva }, reservaDto);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en POST /api/reservas");
                return StatusCode(500);
            }
        }
    }
}
