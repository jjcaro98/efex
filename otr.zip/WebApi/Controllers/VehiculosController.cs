using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Renting.BaseLine.Application.Vehiculos.CreateVehiculo;
using Renting.BaseLine.Application.Vehiculos.UpdateVehiculo;
using Renting.BaseLine.Application.Vehiculos.GetVehiculos;
using Renting.BaseLine.Domain.Entities;
using Renting.BaseLine.Domain.Repositories;

namespace Renting.BaseLine.WebApi.Controllers
{
    [Route("api/vehiculos")]
    [ApiController]
    public class VehiculosController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<VehiculosController> _logger;
        private readonly IRepository<EstadoVehiculo> _estadoVehiculoRepository;
        private readonly IRepository<TipoVehiculo> _tipoVehiculoRepository;
        public VehiculosController(IMediator mediator, ILogger<VehiculosController> logger, IRepository<EstadoVehiculo> estadoVehiculoRepository, IRepository<TipoVehiculo> tipoVehiculoRepository)
        {
            _mediator = mediator;
            _logger = logger;
            _estadoVehiculoRepository = estadoVehiculoRepository;
            _tipoVehiculoRepository = tipoVehiculoRepository;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Post([FromBody] CreateVehiculoCommand command)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                var vehiculoDto = await _mediator.Send(command);
                return CreatedAtAction(nameof(Post), new { id = vehiculoDto.IdVehiculo }, vehiculoDto);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en POST /api/vehiculos");
                return StatusCode(500);
            }
        }

        [HttpGet("filtrar")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<object>>> GetByEstadoYFecha([FromQuery] string? estadoDescripcion = null, [FromQuery] DateTime? fecha = null)
        {
            try
            {
                if (string.IsNullOrEmpty(estadoDescripcion) && !fecha.HasValue)
                {
                    var queryAll = new GetVehiculosByEstadoYFechaQuery { EstadoDescripcion = "", Fecha = null };
                    var todos = await _mediator.Send(queryAll);
                    if (!todos.Any())
                        return NotFound();
                    return Ok(todos);
                }
                var query = new GetVehiculosByEstadoYFechaQuery { EstadoDescripcion = estadoDescripcion ?? "", Fecha = fecha };
                var vehiculos = await _mediator.Send(query);
                if (!vehiculos.Any())
                    return NotFound();
                return Ok(vehiculos);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en GET /api/vehiculos/filtrar");
                return StatusCode(500);
            }
        }

        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Put(int id, [FromBody] UpdateVehiculoCommand command)
        {
            try
            {
                if (id != command.IdVehiculo)
                    return BadRequest();
                var result = await _mediator.Send(command);
                if (!result)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en PUT /api/vehiculos/{id}");
                return StatusCode(500);
            }
        }

        [HttpGet("estados")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<EstadoVehiculo>>> GetEstadosVehiculo()
        {
            try
            {
                var estados = await _estadoVehiculoRepository.GetAsync();
                return Ok(estados);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en GET /api/vehiculos/estados");
                return StatusCode(500);
            }
        }

        [HttpGet("tipos")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<TipoVehiculo>>> GetTiposVehiculo()
        {
            try
            {
                var tipos = await _tipoVehiculoRepository.GetAsync();
                return Ok(tipos);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en GET /api/vehiculos/tipos");
                return StatusCode(500);
            }
        }
    }
}
