﻿using Microsoft.ApplicationInsights.Extensibility;
using Renting.BaseLine.Infrastructure.Extensions;
using Renting.BaseLine.Infrastructure.Logger;
using Renting.BaseLine.WebApi.Base.Authentication;
using Renting.BaseLine.WebApi.Base.Extensions;
using Renting.BaseLine.WebApi.Base.Filters;
using Renting.BaseLine.WebApi.Base.HealthChecks;
using Renting.BaseLine.WebApi.Base.Middlewares;

var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;

builder.Services.AddRentingLogger(configuration);

// Add services to the container.
builder.Services.AddControllers(options =>
{
    options.Filters.Add(typeof(AppExceptionFilterAttribute));
});
builder.Services.AddSingleton<IAzureB2CKeyValidation>(new AzureB2CKeyValidation(configuration));
builder.Services.AddB2CAuthentication(configuration);
builder.Services.AddApplicationInsightsTelemetry(configuration);
builder.Services.AddTransient<AddRequestBodyToTelemetryMiddleware>();
builder.Services.AddSingleton<ITelemetryInitializer, FilterHealthchecksTelemetryInitializer>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddRentingSwagger();
builder.Services.AddRentingHealthChecks(configuration);
builder.Services.AddRentingCors(configuration);

builder.Services.AddApplication(configuration);
builder.Services.AddInfrastructure(configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

if (configuration.GetValue<bool>("ApplicationInsights:IncludeRequestBody"))
{
    app.UseMiddleware<AddRequestBodyToTelemetryMiddleware>();
}

app.UsePathBase(configuration.GetValue("PathBase", string.Empty));

app.UseRentingCors();
app.UseRentingHeaders();
app.UseRentingSwagger(configuration);
app.UseRentingHealthChecks(configuration);

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
