﻿using System.Text;
using System.Text.Json;
using Azure.Messaging.ServiceBus;
using MediatR;
using Microsoft.Extensions.Options;
using Renting.BaseLine.Application.Services.Notifications;
using Renting.BaseLine.Infrastructure.ServiceBus;
using SmartFormat;

namespace Renting.BaseLine.Worker.Base
{
    public class BaseMessageHandler : BackgroundService
    {
        private readonly Serilog.ILogger _logger;
        private readonly string _queueName;
        private readonly MessageResolverService _messageResolver;
        private readonly INotificationService _notificationService;
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly IOptions<ServiceBusOptions> _options;
        private readonly ServiceBusClient _client;
        private readonly ServiceBusReceiver _receiver;
        private readonly ServiceBusSender _sender;

        public BaseMessageHandler(string queueName,
            MessageResolverService messageResolver,
            INotificationService notificationService,
            IServiceScopeFactory serviceScopeFactory,
            IOptions<ServiceBusOptions> options,
            Serilog.ILogger logger)
        {
            _queueName = queueName;
            _logger = logger;
            _messageResolver = messageResolver;
            _notificationService = notificationService;
            _serviceScopeFactory = serviceScopeFactory;
            _options = options;

            _client = new ServiceBusClient(_options.Value.Endpoint);
            _receiver = _client.CreateReceiver(queueName);
            _sender = _client.CreateSender(queueName);
        }

        protected async override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (true)
            {
                stoppingToken.ThrowIfCancellationRequested();

                try
                {
                    var message = await _receiver.ReceiveMessageAsync(cancellationToken: stoppingToken);

                    if (message is not null)
                    {
                        await ProcessAsync(message, stoppingToken);
                    }
                    else
                    {
                        await Task.Delay(1000, stoppingToken);
                    }
                }
                catch (Exception exception)
                {
                    _logger.Error(exception, "Error al procesar el mensaje");
                }
            }
        }

        private async Task ProcessAsync(ServiceBusReceivedMessage message, CancellationToken stoppingToken)
        {
            try
            {
                await ProcessMessageAsync(message, stoppingToken);
                await _receiver.CompleteMessageAsync(message, stoppingToken);
            }
            catch (Exception exception)
            {
                _logger.Error(exception, "Error al procesar el mensaje");

                if (message.ApplicationProperties.ContainsKey("ScheduleDeliveryCount"))
                {
                    if (!IsExternalServiceException(exception))
                    {
                        _logger.Error(exception, "Error al procesar el mensaje despues de los intentos configurados {QueueName} - {QueueMessage}", _queueName, Encoding.UTF8.GetString(message.Body));

                        await _receiver.DeadLetterMessageAsync(message, cancellationToken: stoppingToken);

                        return;
                    }

                    var scheduleDeliveryCount = (int)message.ApplicationProperties["ScheduleDeliveryCount"];

                    if (scheduleDeliveryCount >= _options.Value.MaxRetryCount)
                    {
                        _logger.Error(exception, "Error al procesar el mensaje despues de los intentos configurados {QueueName} - {QueueMessage}", _queueName, Encoding.UTF8.GetString(message.Body));

                        await _receiver.DeadLetterMessageAsync(message, cancellationToken: stoppingToken);
                        await SendNotificationAsync(message, exception);

                        return;
                    }
                    else
                    {
                        await ScheduleMessageAsync(scheduleDeliveryCount + 1, message, stoppingToken);
                    }

                    await _receiver.CompleteMessageAsync(message, stoppingToken);
                }
                else if (message.DeliveryCount >= _options.Value.MaxDeliveryCount)
                {
                    await ScheduleMessageAsync(1, message, stoppingToken);
                    await _receiver.CompleteMessageAsync(message, stoppingToken);
                }
            }
        }

        protected virtual bool IsExternalServiceException(Exception exception)
        {
            if (exception is HttpRequestException)
            {
                return true;
            }

            return false;
        }

        protected virtual async Task SendNotificationAsync(ServiceBusReceivedMessage message, Exception exception)
        {
            try
            {
                await _notificationService.SendAsync(_options.Value.Notifications.Sender,
                    _options.Value.Notifications.Recipients,
                    Smart.Format(_options.Value.Notifications.Title, new { QueueName = _queueName }),
                    Smart.Format(_options.Value.Notifications.Body, new
                    {
                        ExceptionMessage = exception.Message,
                        MessageContent = message.Body.ToString(),
                        Exception = exception.ToString()
                    }));
            }
            catch (Exception notificationException)
            {
                _logger.Error(notificationException, "Error al enviar la notificacion");
            }
        }

        private async Task ScheduleMessageAsync(int scheduleDeliveryCount, ServiceBusReceivedMessage receivedMessage, CancellationToken stoppingToken)
        {
            var message = new ServiceBusMessage(receivedMessage);
            message.ApplicationProperties["ScheduleDeliveryCount"] = scheduleDeliveryCount;

            await _sender.ScheduleMessageAsync(message, DateTimeOffset.UtcNow.AddSeconds(_options.Value.RetrySeconds), stoppingToken);
        }

        protected virtual async Task ProcessMessageAsync(ServiceBusReceivedMessage serviceBusMessage, CancellationToken stoppingToken)
        {
            var messageString = serviceBusMessage.Body.ToString();
            var message = JsonSerializer.Deserialize<Message>(messageString);

            if (message is null)
            {
                return;
            }

            var command = _messageResolver.Resolve(message.Type, message.Content);

            if (command is null)
            {
                return;
            }

            using var scope = _serviceScopeFactory.CreateScope();

            var mediator = scope.ServiceProvider.GetRequiredService<IMediator>();

            await mediator.Send(command, stoppingToken);
        }
    }
}
