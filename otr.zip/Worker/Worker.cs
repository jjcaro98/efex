﻿using Microsoft.Extensions.Options;
using Renting.BaseLine.Application.Services;
using Renting.BaseLine.Application.Services.Notifications;
using Renting.BaseLine.Infrastructure.ServiceBus;
using Renting.BaseLine.Worker.Base;

namespace Renting.BaseLine.Worker;

public class Worker : BaseMessageHandler
{
    public Worker(Serilog.ILogger logger,
        MessageResolverService messageResolver,
        INotificationService notificationService,
        IServiceScopeFactory serviceScopeFactory,
        IOptions<ServiceBusOptions> options) :base(options.Value.Queues[IMessageService.Base], messageResolver, notificationService, serviceScopeFactory, options, logger)
    {
    }

    protected override bool IsExternalServiceException(Exception exception)
    {
        if (exception is AggregateException aggregateException)
        {
            if (aggregateException.InnerException is Microsoft.Data.SqlClient.SqlException)
            {
                return true;
            }

            if (aggregateException.InnerException is HttpRequestException)
            {
                return true;
            }
        }

        return base.IsExternalServiceException(exception);
    }
}
